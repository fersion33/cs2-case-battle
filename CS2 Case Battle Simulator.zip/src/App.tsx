import { useEffect, useState } from "react";
import { bootstrap, useMe } from "./lib/engine";
import { ToastHost, cx } from "./lib/ui";
import Home from "./screens/Home";
import Cases, { CaseView } from "./screens/Cases";
import Battles, { RoomView } from "./screens/Battles";
import Upgrade from "./screens/Upgrade";
import Profile from "./screens/Profile";
import PlayerView from "./screens/PlayerView";

bootstrap();

const NAV: [string, string, string][] = [["/", "Главная", "◆"], ["/cases", "Кейсы", "▣"], ["/battles", "Баттлы", "⚔"], ["/upgrade", "Апгрейд", "⬆"], ["/profile", "Профиль", "☺"]];
const hashPath = () => location.hash.replace(/^#/, "") || "/";

export default function App() {
  const [path, setPath] = useState(hashPath());
  const me = useMe();
  useEffect(() => { const f = () => { setPath(hashPath()); document.getElementById("scroll")?.scrollTo(0, 0); }; addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []);
  const go = (p: string) => { location.hash = p; };
  const [route, query] = path.split("?");
  const seg = route.split("/").filter(Boolean);
  const tab = new URLSearchParams(query).get("tab") ?? undefined;
  let view;
  switch (seg[0]) {
    case "cases": view = <Cases go={go} />; break;
    case "case": view = <CaseView key={seg[1]} id={seg[1]} go={go} />; break;
    case "battles": view = <Battles go={go} />; break;
    case "room": view = <RoomView key={seg[1] + me.id} code={seg[1]} go={go} />; break;
    case "upgrade": view = <Upgrade key={me.id} />; break;
    case "profile": view = <Profile key={me.id + (tab ?? "")} go={go} initTab={tab} />; break;
    case "player": view = <PlayerView id={seg[1]} go={go} />; break;
    default: view = <Home go={go} />;
  }
  const active = "/" + (seg[0] === "case" ? "cases" : seg[0] === "room" ? "battles" : seg[0] === "player" ? "profile" : seg[0] ?? "");
  return (
    <div className="mx-auto flex h-full max-w-5xl flex-col border-x border-line/40 bg-ink/60">
      <ToastHost />
      <div id="scroll" className="min-h-0 flex-1 overflow-y-auto">{view}</div>
      <nav className="safe-b grid shrink-0 grid-cols-5 border-t border-line bg-panel/95 backdrop-blur">
        {NAV.map(([to, l, i]) => (
          <button key={to} onClick={() => go(to)} className={cx("relative flex flex-col items-center gap-0.5 py-2.5 transition", active === to ? "text-white" : "text-white/40")}>
            {active === to && <span className="absolute inset-x-4 top-0 h-0.5 bg-violet shadow-[0_0_10px_#8d5bff]" />}
            <span className="text-lg leading-none">{i}</span><span className="font-display text-[10px] font-semibold uppercase tracking-wider">{l}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
