import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { RARITY, CASE_BY_ID } from "../data/cases";
import { SKIN_BY_ID, type Skin } from "../data/skins";
import { AVATAR_COLORS, fmt, type Drop } from "./engine";

export const cx = (...a: (string | false | undefined | null)[]) => a.filter(Boolean).join(" ");
export const rc = (s: Skin) => RARITY[s.rarity].color;

// ---- toasts ----
type T = { id: number; text: string; bad?: boolean };
const tl = new Set<(t: T) => void>();
export const toast = (text: string, bad = false) => tl.forEach((f) => f({ id: Math.random(), text, bad }));
export const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Ошибка");
export const toastErr = (e: unknown) => toast(errMsg(e), true);
export function ToastHost() {
  const [list, setList] = useState<T[]>([]);
  useEffect(() => {
    const f = (t: T) => { setList((l) => [...l, t]); setTimeout(() => setList((l) => l.filter((x) => x.id !== t.id)), 2800); };
    tl.add(f); return () => void tl.delete(f);
  }, []);
  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-4">
      {list.map((t) => (
        <div key={t.id} className={cx("rise hud px-4 py-2.5 text-sm font-semibold shadow-xl", t.bad ? "bg-red text-white" : "bg-white text-black")}>{t.text}</div>
      ))}
    </div>
  );
}

// ---- images ----
const loaded = new Set<string>();
export function SkinImg({ skin, className = "" }: { skin: Skin; className?: string }) {
  const [bad, setBad] = useState(false);
  const [ok, setOk] = useState(loaded.has(skin.image));
  if (bad)
    return (
      <div className={cx("flex flex-col items-center justify-center p-2 text-center text-[10px] leading-tight text-white/50", className)}>
        <div className="mb-1 h-6 w-10 rounded border border-dashed border-white/25" />
        {skin.name}
      </div>
    );
  return (
    <img
      src={skin.image} alt={skin.name} loading="lazy" decoding="async" draggable={false}
      onLoad={() => { loaded.add(skin.image); setOk(true); }} onError={() => setBad(true)}
      className={cx("object-contain transition-opacity duration-300 drop-shadow-[0_6px_10px_rgba(0,0,0,.6)]", ok ? "opacity-100" : "opacity-0", className)}
    />
  );
}

export function Money({ n, className = "", sign }: { n: number; className?: string; sign?: boolean }) {
  return (
    <span className={cx("inline-flex items-center gap-1 font-mono font-bold tabular-nums", className)}>
      <span className="inline-block h-[0.8em] w-[0.8em] rounded-full bg-gradient-to-br from-gold to-[#c98a00] ring-1 ring-black/40" />
      {sign && n > 0 ? "+" : ""}{fmt(n)}
    </span>
  );
}

export function Avatar({ idx, nick, size = 36 }: { idx: number; nick: string; size?: number }) {
  const c = AVATAR_COLORS[idx % AVATAR_COLORS.length];
  return (
    <div className="hud flex shrink-0 items-center justify-center font-display font-bold text-black" style={{ width: size, height: size, background: `linear-gradient(135deg,${c},${c}88)`, fontSize: size * 0.42 }}>
      {nick.slice(0, 2).toUpperCase()}
    </div>
  );
}

export function Btn({ children, onClick, tone = "violet", disabled, className = "", busy }: { children: ReactNode; onClick?: () => void; tone?: "violet" | "gold" | "red" | "ghost" | "blue"; disabled?: boolean; className?: string; busy?: boolean }) {
  const tones = { violet: "bg-violet text-white", gold: "bg-gold text-black", red: "bg-red text-white", blue: "bg-blue text-white", ghost: "bg-panel2 text-white border border-line" };
  return (
    <button disabled={disabled || busy} onClick={onClick} className={cx("hud font-display px-4 py-3 text-sm font-bold uppercase tracking-wider transition active:scale-95 disabled:opacity-40 disabled:active:scale-100", tones[tone], className)}>
      {busy ? "…" : children}
    </button>
  );
}

export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="rise max-h-[88%] w-full max-w-md overflow-y-auto rounded-t-2xl border-t border-line bg-panel p-4" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between">
          <div className="font-display text-lg font-bold">{title}</div>
          <button onClick={onClose} className="h-8 w-8 rounded-full bg-panel2 text-lg text-white/70">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function useNow(ms = 250) {
  const [n, setN] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setN(Date.now()), ms); return () => clearInterval(t); }, [ms]);
  return n;
}

export function SkinCard({ skin, wear, value, onClick, selected, badge, dim }: { skin: Skin; wear?: string; value?: number; onClick?: () => void; selected?: boolean; badge?: ReactNode; dim?: boolean }) {
  const c = rc(skin);
  return (
    <button onClick={onClick} style={{ ["--c" as string]: c }} className={cx("rar-bg hud relative flex flex-col overflow-hidden border text-left transition active:scale-[.97]", selected ? "glow border-white" : "border-line", dim && "opacity-40")}>
      <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: c }} />
      <SkinImg skin={skin} className="mx-auto mt-2 h-20 w-full px-2" />
      <div className="px-2.5 pb-2.5 pt-1">
        <div className="truncate text-[10px] font-semibold uppercase tracking-wide" style={{ color: c }}>{skin.weapon}</div>
        <div className="truncate text-[13px] font-bold leading-tight">{skin.skin}</div>
        <div className="mt-0.5 truncate text-[9px] uppercase tracking-wide text-white/40">{skin.quality} · {RARITY[skin.rarity].label}</div>
        <div className="mt-1 flex items-center justify-between gap-1">
          <Money n={value ?? skin.price} className="text-[12px] text-gold" />
          {wear && <span className="rounded bg-black/50 px-1 font-mono text-[10px] text-white/70">{wear}</span>}
        </div>
      </div>
      {badge}
    </button>
  );
}

// ---- рулетка: анимация показывает ЗАРАНЕЕ определённый результат ----
const W = 92, WIN = 34, LEN = 42;
function seeded(seed: string) {
  let h = 2166136261;
  for (const ch of seed) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  return () => { h = Math.imul(h ^ (h >>> 15), 2246822507); h ^= h >>> 13; return ((h >>> 0) % 100000) / 100000; };
}
export function Roller({ caseId, result, startAt, duration = 5200, seed, onDone, compact }: { caseId: string; result: Drop; startAt: number; duration?: number; seed: string; onDone?: () => void; compact?: boolean }) {
  const strip = useMemo(() => {
    const r = seeded(seed), pool = CASE_BY_ID[caseId].items;
    return Array.from({ length: LEN }, (_, i) => {
      if (i === WIN) return SKIN_BY_ID[result.skinId];
      let x = r() * 100; for (const it of pool) { x -= it.chance; if (x < 0) return SKIN_BY_ID[it.skinId]; }
      return SKIN_BY_ID[pool[0].skinId];
    });
  }, [caseId, result.skinId, seed]);
  const ref = useRef<HTMLDivElement>(null);
  const done = useRef(onDone); done.current = onDone;
  const jitter = useMemo(() => (seeded(seed + "j")() - 0.5) * (W * 0.6), [seed]);
  const size = compact ? W * 0.72 : W;
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const to = -(WIN * size + size / 2 + jitter * (size / W));
    const el0 = Date.now() - startAt;
    if (el0 >= duration) { el.style.transform = `translateX(${to}px)`; done.current?.(); return; }
    el.style.transform = "translateX(0px)";
    const a = el.animate([{ transform: "translateX(0px)" }, { transform: `translateX(${to}px)` }], { duration, easing: "cubic-bezier(.08,.6,.12,1)", fill: "forwards", delay: Math.max(0, -el0) });
    if (el0 > 0) a.currentTime = el0;
    a.finished.then(() => done.current?.()).catch(() => {});
    return () => a.cancel();
  }, [startAt, duration, size, jitter]);
  return (
    <div className="relative overflow-hidden border-y border-line bg-black/60" style={{ height: compact ? 92 : 128 }}>
      <div className="absolute inset-y-0 left-1/2 z-10 w-0.5 bg-gold shadow-[0_0_14px_2px_#ffc83d]" />
      <div className="absolute left-1/2 top-0 z-10 h-0 w-0 -translate-x-1/2 border-x-[7px] border-t-[9px] border-x-transparent border-t-gold" />
      <div className="absolute inset-y-0 left-0 z-10 w-10 bg-gradient-to-r from-ink to-transparent" />
      <div className="absolute inset-y-0 right-0 z-10 w-10 bg-gradient-to-l from-ink to-transparent" />
      <div ref={ref} className="absolute inset-y-0 flex will-change-transform" style={{ left: "50%" }}>
        {strip.map((s, i) => (
          <div key={i} style={{ width: size, ["--c" as string]: rc(s) }} className="rar-bg flex shrink-0 flex-col items-center justify-center border-r border-black">
            <SkinImg skin={s} className={compact ? "h-12 w-16" : "h-16 w-20"} />
            <div className="mt-0.5 h-0.5 w-8" style={{ background: rc(s) }} />
          </div>
        ))}
      </div>
    </div>
  );
}

export function Header({ title, sub, right, onBack }: { title: string; sub?: string; right?: ReactNode; onBack?: () => void }) {
  return (
    <div className="flex items-center gap-3 px-4 pb-3 pt-4">
      {onBack && <button onClick={onBack} className="hud flex h-9 w-9 items-center justify-center bg-panel2 text-lg">‹</button>}
      <div className="min-w-0 flex-1">
        <div className="font-display text-2xl font-bold uppercase leading-none">{title}</div>
        {sub && <div className="mt-1 text-xs text-white/50">{sub}</div>}
      </div>
      {right}
    </div>
  );
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: [T, string][] }) {
  return (
    <div className="flex gap-1.5 overflow-x-auto px-4 pb-3">
      {items.map(([k, l]) => (
        <button key={k} onClick={() => onChange(k)} className={cx("hud shrink-0 px-3.5 py-2 font-display text-xs font-bold uppercase tracking-wider transition", value === k ? "bg-white text-black" : "bg-panel2 text-white/60")}>{l}</button>
      ))}
    </div>
  );
}
