// "Сервер" игры: все правила, броски RNG, балансы и награды считаются здесь, в одной атомарной транзакции
// (navigator.locks + единый коммит). UI получает уже сохранённый результат и только анимирует его.
import { useSyncExternalStore } from "react";
import { SKINS, SKIN_BY_ID, type Skin } from "../data/skins";
import { CASE_BY_ID, WEAR_STEPS, wearOf } from "../data/cases";

export interface Item { iid: string; skinId: string; float: number; wear: string; value: number; at: number; src: string }
export interface TxRec { id: string; at: number; kind: string; amount: number; text: string }
export interface UpgradeRec { id: string; at: number; srcName: string; srcValue: number; targetName: string; targetValue: number; chance: number; roll: number; success: boolean }
export interface Counters { date: string; cases: number; battles: number; wins: number; sells: number; upgrades: number }
export interface Player {
  id: string; uid: string; nick: string; avatar: number; balance: number; createdAt: number;
  inventory: Item[]; tx: TxRec[]; upgrades: UpgradeRec[]; friends: string[]; invites: { room: string; from: string; at: number }[];
  stats: { cases: number; battles: number; wins: number; losses: number; upgrades: number; upgradeWins: number };
  day: Counters; season: { key: string; cases: number; wins: number };
  daily: { last: string; streak: number; freeCase: string }; claimed: Record<string, string>; idem: Record<string, unknown>;
}
export interface Slot { slot: number; pid: string | null; nick: string; avatar: number; bot?: boolean; lastSeen: number }
export interface Drop { skinId: string; float: number; value: number }
export interface Room {
  code: string; mode: Mode; size: number; cases: string[]; visibility: "public" | "private"; hostId: string; botsMode: boolean;
  status: "waiting" | "running" | "finished"; players: Slot[]; created: number; startedAt?: number; cost: number;
  rounds?: Drop[][]; tie: number; winners?: number[]; totals?: number[]; settled?: boolean; rematch?: string; prize?: number;
}
export type Mode = "1v1" | "2v2" | "3p" | "4p";
export const MODES: Record<Mode, { label: string; size: number; sub: string }> = {
  "1v1": { label: "1 на 1", size: 2, sub: "Дуэль" },
  "2v2": { label: "2 на 2", size: 4, sub: "Команды" },
  "3p": { label: "3 игрока", size: 3, sub: "Каждый сам" },
  "4p": { label: "4 игрока", size: 4, sub: "Каждый сам" },
};
export const TEAM = (mode: Mode, slot: number) => (mode === "2v2" ? (slot < 2 ? 0 : 1) : slot);
export const T_COUNTDOWN = 3500, T_ROUND = 6800, T_TAIL = 2500;
export const roomEnd = (r: Room) => (r.startedAt ?? 0) + T_COUNTDOWN + r.rounds!.length * T_ROUND + T_TAIL;

interface DB { players: Record<string, Player>; rooms: Record<string, Room>; feed: { at: number; nick: string; skinId: string; value: number; src: string }[] }
const KEY = "cs2cb:db:v1";
const bc = typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("cs2cb") : null;
let raw = "", cache: DB = { players: {}, rooms: {}, feed: [] }, version = 0;
const subs = new Set<() => void>();
function read(): DB {
  const s = localStorage.getItem(KEY) ?? "";
  if (s !== raw) { raw = s; cache = s ? JSON.parse(s) : { players: {}, rooms: {}, feed: [] }; version++; }
  return cache;
}
const bump = () => { read(); subs.forEach((f) => f()); };
bc?.addEventListener("message", bump);
addEventListener("storage", (e) => e.key === KEY && bump());
export function useDB() {
  useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => (read(), version));
  return read();
}

async function transact<T>(fn: (db: DB) => T): Promise<T> {
  const run = () => {
    const db: DB = JSON.parse(JSON.stringify(read()));
    const out = fn(db);
    localStorage.setItem(KEY, JSON.stringify(db));
    bc?.postMessage(1);
    bump();
    return out;
  };
  return navigator.locks ? navigator.locks.request("cs2cb", async () => run()) : run();
}

const rnd = () => crypto.getRandomValues(new Uint32Array(2)).reduce((a, v, i) => a + v / 2 ** (32 * (i + 1)), 0);
const uuid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const dayKey = (t = Date.now()) => new Date(t).toISOString().slice(0, 10);
const seasonKey = (t = Date.now()) => { const d = new Date(t); return `S${d.getUTCFullYear()}-${Math.floor(d.getUTCMonth() / 3) + 1}`; };
export const fmt = (n: number) => Math.round(n).toLocaleString("ru-RU").replace(/ /g, " ");
export const NICKS = ["Ghost", "Viper", "Nova", "Raven", "Cobra", "Zero", "Blaze", "Phantom", "Omen", "Rogue"];
export const AVATAR_COLORS = ["#8d5bff", "#4b7bff", "#ff3d4f", "#ffc83d", "#2dd4a0", "#e04bd8", "#ff8a3d", "#3dd5ff"];

const fresh = (): Player => ({
  id: "p_" + uuid(), uid: "#" + Math.floor(10000000 + Math.random() * 89999999), nick: NICKS[Math.floor(Math.random() * NICKS.length)] + Math.floor(100 + Math.random() * 900),
  avatar: Math.floor(Math.random() * AVATAR_COLORS.length), balance: 50000, createdAt: Date.now(), inventory: [], tx: [{ id: uuid(), at: Date.now(), kind: "bonus", amount: 50000, text: "Стартовый бонус регистрации" }],
  upgrades: [], friends: [], invites: [], stats: { cases: 0, battles: 0, wins: 0, losses: 0, upgrades: 0, upgradeWins: 0 },
  day: { date: dayKey(), cases: 0, battles: 0, wins: 0, sells: 0, upgrades: 0 }, season: { key: seasonKey(), cases: 0, wins: 0 },
  daily: { last: "", streak: 0, freeCase: "" }, claimed: {}, idem: {},
});
function norm(p: Player) {
  if (p.day.date !== dayKey()) p.day = { date: dayKey(), cases: 0, battles: 0, wins: 0, sells: 0, upgrades: 0 };
  if (p.season.key !== seasonKey()) p.season = { key: seasonKey(), cases: 0, wins: 0 };
}
function addTx(p: Player, kind: string, amount: number, text: string) {
  p.balance += amount;
  p.tx.unshift({ id: uuid(), at: Date.now(), kind, amount, text });
  p.tx.length = Math.min(p.tx.length, 150);
}
function remember(p: Player, reqId: string, out: unknown) {
  p.idem[reqId] = out;
  const ks = Object.keys(p.idem);
  if (ks.length > 40) delete p.idem[ks[0]];
  return out;
}
const fail = (m: string): never => { throw new Error(m); };

// ---------- Сессия ----------
export function activeId() { return sessionStorage.getItem("cs2cb:pid") ?? localStorage.getItem("cs2cb:active") ?? ""; }
export function useMe(): Player {
  const db = useDB();
  return db.players[activeId()] ?? Object.values(db.players)[0];
}
export function bootstrap() {
  const db = read();
  let id = activeId();
  if (!db.players[id]) {
    const p = fresh();
    db.players[p.id] = p; id = p.id;
    localStorage.setItem(KEY, JSON.stringify(db));
    localStorage.setItem("cs2cb:active", id);
    bump();
  }
  sessionStorage.setItem("cs2cb:pid", id);
}
export function switchPlayer(id: string) { sessionStorage.setItem("cs2cb:pid", id); localStorage.setItem("cs2cb:active", id); bump(); }
export async function newPlayer() {
  const p = fresh();
  await transact((db) => { db.players[p.id] = p; });
  switchPlayer(p.id);
}
export const me = (db: DB) => db.players[activeId()] ?? fail("Игрок не найден");
export async function setProfile(nick: string, avatar: number) {
  nick = nick.trim().slice(0, 16);
  if (nick.length < 3) throw new Error("Ник: минимум 3 символа");
  await transact((db) => { const p = me(db); p.nick = nick; p.avatar = avatar; });
}

// ---------- Предметы ----------
export function dropFor(skin: Skin, float?: number): Drop {
  const f = float ?? skin.minFloat + rnd() * (skin.maxFloat - skin.minFloat);
  const w = wearOf(f);
  return { skinId: skin.id, float: +f.toFixed(4), value: Math.max(10, Math.min(5_000_000, Math.round(skin.price * w.mult))) };
}
export const upgradeTarget = (skin: Skin) => dropFor(skin, Math.min(Math.max(0.25, skin.minFloat), skin.maxFloat));
function mkItem(d: Drop, src: string): Item { return { iid: "i_" + uuid(), skinId: d.skinId, float: d.float, wear: wearOf(d.float).key, value: d.value, at: Date.now(), src }; }
export const wearLabel = (key: string) => WEAR_STEPS.find((w) => w.key === key)?.label ?? key;
export const invValue = (p: Player) => p.inventory.reduce((a, i) => a + i.value, 0);

export function rollCase(caseId: string): Drop {
  const c = CASE_BY_ID[caseId] ?? fail("Кейс не найден");
  let r = rnd() * 100;
  for (const it of c.items) { r -= it.chance; if (r < 0) return dropFor(SKIN_BY_ID[it.skinId]); }
  return dropFor(SKIN_BY_ID[c.items[c.items.length - 1].skinId]);
}
function feed(db: DB, p: Player, d: Drop, src: string) {
  if (d.value >= 5000) { db.feed.unshift({ at: Date.now(), nick: p.nick, skinId: d.skinId, value: d.value, src }); db.feed.length = Math.min(db.feed.length, 25); }
}

export async function openCase(caseId: string, reqId: string): Promise<Item> {
  return transact((db) => {
    const p = me(db); norm(p);
    if (p.idem[reqId]) return p.idem[reqId] as Item;
    const c = CASE_BY_ID[caseId] ?? fail("Кейс не найден");
    if (c.free) { if (p.daily.freeCase === dayKey()) fail("Кейс дня уже открыт сегодня"); p.daily.freeCase = dayKey(); }
    else { if (p.balance < c.price) fail("Недостаточно монет"); addTx(p, "case", -c.price, `Открытие «${c.name}»`); }
    const d = rollCase(caseId), item = mkItem(d, "case:" + c.name);
    p.inventory.unshift(item);
    p.stats.cases++; p.day.cases++; p.season.cases++;
    feed(db, p, d, c.name);
    return remember(p, reqId, item) as Item;
  });
}
export async function sellItems(iids: string[]): Promise<number> {
  return transact((db) => {
    const p = me(db); norm(p);
    const set = new Set(iids), sold = p.inventory.filter((i) => set.has(i.iid));
    if (!sold.length) fail("Предметы не найдены");
    const sum = sold.reduce((a, i) => a + i.value, 0);
    p.inventory = p.inventory.filter((i) => !set.has(i.iid));
    addTx(p, "sell", sum, sold.length === 1 ? `Продажа ${SKIN_BY_ID[sold[0].skinId].name}` : `Продажа ${sold.length} предметов`);
    p.day.sells += sold.length;
    return sum;
  });
}

// ---------- Апгрейд ----------
export function upgradeChance(srcValue: number, targetValue: number) {
  return Math.min(86, Math.max(0.5, Math.floor((srcValue / targetValue) * 95 * 100) / 100));
}
export interface UpgradeResult { success: boolean; roll: number; chance: number; reward?: Item; rec: UpgradeRec }
export async function doUpgrade(iid: string, targetSkinId: string, reqId: string): Promise<UpgradeResult> {
  return transact((db) => {
    const p = me(db); norm(p);
    if (p.idem[reqId]) return p.idem[reqId] as UpgradeResult;
    const src = p.inventory.find((i) => i.iid === iid) ?? fail("Предмет не найден в инвентаре");
    const skin = SKIN_BY_ID[targetSkinId] ?? fail("Цель не найдена");
    const t = upgradeTarget(skin);
    if (t.value < src.value * 1.1) fail("Цель должна быть дороже минимум на 10%");
    const chance = upgradeChance(src.value, t.value), roll = +(rnd() * 100).toFixed(4), success = roll < chance;
    p.inventory = p.inventory.filter((i) => i.iid !== iid); // исходный предмет списывается в любом случае (правило показано заранее)
    let reward: Item | undefined;
    if (success) { reward = mkItem(t, "upgrade"); p.inventory.unshift(reward); p.stats.upgradeWins++; addTx(p, "bonus", 100, "Бонус за успешный апгрейд"); feed(db, p, t, "Апгрейд"); }
    p.stats.upgrades++; p.day.upgrades++;
    const rec: UpgradeRec = { id: uuid(), at: Date.now(), srcName: SKIN_BY_ID[src.skinId].name, srcValue: src.value, targetName: skin.name, targetValue: t.value, chance, roll, success };
    p.upgrades.unshift(rec); p.upgrades.length = Math.min(p.upgrades.length, 60);
    p.tx.unshift({ id: uuid(), at: Date.now(), kind: "upgrade", amount: 0, text: `Апгрейд ${rec.srcName} → ${rec.targetName}: ${success ? "успех" : "неудача"}` });
    return remember(p, reqId, { success, roll, chance, reward, rec }) as UpgradeResult;
  });
}

// ---------- Бонусы и задания ----------
export const DAILY_REWARDS = [1000, 1500, 2000, 3000, 4000, 5000, 10000];
export function dailyState(p: Player) {
  const today = dayKey(), yest = dayKey(Date.now() - 864e5);
  const canClaim = p.daily.last !== today;
  const streak = p.daily.last === today || p.daily.last === yest ? p.daily.streak : 0;
  return { canClaim, streak, nextIdx: (canClaim ? streak : streak - 1 + 0) % 7 };
}
export async function claimDaily(): Promise<number> {
  return transact((db) => {
    const p = me(db); norm(p);
    if (p.daily.last === dayKey()) fail("Награда за сегодня уже получена");
    p.daily.streak = p.daily.last === dayKey(Date.now() - 864e5) ? p.daily.streak + 1 : 1;
    p.daily.last = dayKey();
    const amt = DAILY_REWARDS[(p.daily.streak - 1) % 7];
    addTx(p, "bonus", amt, `Ежедневная награда · серия ${p.daily.streak}`);
    return amt;
  });
}
export interface Quest { id: string; title: string; goal: number; reward: number; period: "daily" | "once" | "season"; prog: (p: Player) => number }
export const QUESTS: Quest[] = [
  { id: "d-cases", title: "Открыть 3 кейса", goal: 3, reward: 800, period: "daily", prog: (p) => p.day.cases },
  { id: "d-battle", title: "Сыграть 1 баттл", goal: 1, reward: 600, period: "daily", prog: (p) => p.day.battles },
  { id: "d-up", title: "Сделать апгрейд", goal: 1, reward: 500, period: "daily", prog: (p) => p.day.upgrades },
  { id: "d-sell", title: "Продать 2 предмета", goal: 2, reward: 400, period: "daily", prog: (p) => p.day.sells },
  { id: "s-cases", title: "Сезон: открыть 100 кейсов", goal: 100, reward: 25000, period: "season", prog: (p) => p.season.cases },
  { id: "s-wins", title: "Сезон: 15 побед в баттлах", goal: 15, reward: 20000, period: "season", prog: (p) => p.season.wins },
  { id: "a-first", title: "Первый кейс", goal: 1, reward: 500, period: "once", prog: (p) => p.stats.cases },
  { id: "a-50", title: "Открыть 50 кейсов", goal: 50, reward: 5000, period: "once", prog: (p) => p.stats.cases },
  { id: "a-win", title: "Первая победа в баттле", goal: 1, reward: 1500, period: "once", prog: (p) => p.stats.wins },
  { id: "a-win10", title: "10 побед в баттлах", goal: 10, reward: 10000, period: "once", prog: (p) => p.stats.wins },
  { id: "a-up", title: "Успешный апгрейд", goal: 1, reward: 1000, period: "once", prog: (p) => p.stats.upgradeWins },
  { id: "a-rich", title: "Инвентарь на 100 000", goal: 100000, reward: 5000, period: "once", prog: (p) => invValue(p) },
  { id: "a-friend", title: "Добавить друга", goal: 1, reward: 700, period: "once", prog: (p) => p.friends.length },
];
export const questKey = (q: Quest) => (q.period === "daily" ? dayKey() : q.period === "season" ? seasonKey() : "once");
export async function claimQuest(id: string): Promise<number> {
  return transact((db) => {
    const p = me(db); norm(p);
    const q = QUESTS.find((x) => x.id === id) ?? fail("Задание не найдено");
    if (p.claimed[id] === questKey(q)) fail("Награда уже получена");
    if (q.prog(p) < q.goal) fail("Задание не выполнено");
    p.claimed[id] = questKey(q);
    addTx(p, "bonus", q.reward, `Награда: ${q.title}`);
    return q.reward;
  });
}

// ---------- Друзья ----------
export async function addFriend(uid: string) {
  await transact((db) => {
    const p = me(db), o = Object.values(db.players).find((x) => x.uid === uid.trim() || x.uid === "#" + uid.trim()) ?? fail("Игрок с таким ID не найден");
    if (o.id === p.id) fail("Нельзя добавить себя");
    if (p.friends.includes(o.id)) fail("Уже в друзьях");
    p.friends.push(o.id); o.friends.push(p.id);
  });
}
export async function removeFriend(id: string) {
  await transact((db) => { const p = me(db); p.friends = p.friends.filter((f) => f !== id); const o = db.players[id]; if (o) o.friends = o.friends.filter((f) => f !== p.id); });
}
export async function inviteFriend(fid: string, room: string) {
  await transact((db) => { const p = me(db), o = db.players[fid] ?? fail("Игрок не найден"); o.invites = [{ room, from: p.nick, at: Date.now() }, ...o.invites.filter((i) => i.room !== room)].slice(0, 10); });
}
export async function dismissInvite(room: string) { await transact((db) => { const p = me(db); p.invites = p.invites.filter((i) => i.room !== room); }); }

// ---------- Баттлы ----------
const BOT_NAMES = ["BOT_Alpha", "BOT_Bravo", "BOT_Delta", "BOT_Echo"];
export const roomCost = (cases: string[]) => cases.reduce((a, c) => a + CASE_BY_ID[c].price, 0);
function code() { const a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; return Array.from({ length: 5 }, () => a[Math.floor(rnd() * a.length)]).join(""); }
function slotFor(p: Player, slot: number): Slot { return { slot, pid: p.id, nick: p.nick, avatar: p.avatar, lastSeen: Date.now() }; }
function startRoom(r: Room) {
  r.rounds = r.cases.flatMap((cid) => [r.players.map(() => rollCase(cid))]);
  r.tie = Math.floor(rnd() * 1000); r.status = "running"; r.startedAt = Date.now();
}
function pay(db: DB, p: Player, r: Room) {
  if (p.balance < r.cost) fail("Недостаточно монет для входа в баттл");
  addTx(p, "battle", -r.cost, `Взнос в баттл ${r.code}`);
}
function refund(db: DB, pid: string, r: Room) { const p = db.players[pid]; if (p) addTx(p, "battle", r.cost, `Возврат взноса · баттл ${r.code}`); }
function fillBots(r: Room) {
  for (let i = 0; i < r.size; i++) if (!r.players.find((s) => s.slot === i)) r.players.push({ slot: i, pid: null, nick: BOT_NAMES[i], avatar: i + 3, bot: true, lastSeen: Date.now() });
  r.players.sort((a, b) => a.slot - b.slot);
}
export async function createRoom(o: { mode: Mode; cases: string[]; visibility: "public" | "private"; bots: boolean }): Promise<string> {
  if (o.cases.length < 1 || o.cases.length > 10) throw new Error("Выберите от 1 до 10 кейсов");
  return transact((db) => {
    const p = me(db); norm(p);
    const r: Room = { code: code(), mode: o.mode, size: MODES[o.mode].size, cases: o.cases, visibility: o.visibility, hostId: p.id, botsMode: o.bots, status: "waiting", players: [slotFor(p, 0)], created: Date.now(), cost: roomCost(o.cases), tie: 0 };
    pay(db, p, r);
    if (o.bots) { fillBots(r); startRoom(r); }
    db.rooms[r.code] = r;
    return r.code;
  });
}
export async function joinRoom(c: string, slotWanted?: number): Promise<string> {
  c = c.trim().toUpperCase();
  return transact((db) => {
    const p = me(db), r = db.rooms[c] ?? fail("Комната не найдена");
    if (r.players.some((s) => s.pid === p.id)) return c;
    if (r.status !== "waiting") fail("Баттл уже начался");
    const free = Array.from({ length: r.size }, (_, i) => i).filter((i) => !r.players.some((s) => s.slot === i));
    if (!free.length) fail("Комната заполнена");
    pay(db, p, r);
    const slot = slotWanted !== undefined && free.includes(slotWanted) ? slotWanted : free[0];
    r.players.push(slotFor(p, slot)); r.players.sort((a, b) => a.slot - b.slot);
    if (r.players.length === r.size) startRoom(r);
    p.invites = p.invites.filter((i) => i.room !== c);
    return c;
  });
}
export async function leaveRoom(c: string) {
  await transact((db) => {
    const p = me(db), r = db.rooms[c];
    if (!r || r.status !== "waiting" || !r.players.some((s) => s.pid === p.id)) return;
    r.players = r.players.filter((s) => s.pid !== p.id); refund(db, p.id, r);
    if (!r.players.length) delete db.rooms[c]; else if (r.hostId === p.id) r.hostId = r.players[0].pid!;
  });
}
export async function findMatch(mode: Mode, cases: string[]): Promise<string> {
  const pid = activeId();
  const cand = Object.values(read().rooms).find((r) => r.status === "waiting" && r.visibility === "public" && !r.botsMode && r.mode === mode && r.cases.join() === cases.join() && !r.players.some((s) => s.pid === pid) && r.players.length < r.size);
  return cand ? joinRoom(cand.code) : createRoom({ mode, cases, visibility: "public", bots: false });
}
export async function heartbeat(c: string) {
  await transact((db) => {
    const p = me(db), now = Date.now(), r = db.rooms[c];
    if (r) { const s = r.players.find((x) => x.pid === p.id); if (s) s.lastSeen = now; }
    for (const room of Object.values(db.rooms)) { // сервер выкидывает отключившихся из лобби с возвратом взноса
      if (room.status !== "waiting") continue;
      const stale = room.players.filter((s) => s.pid && now - s.lastSeen > 40000);
      stale.forEach((s) => refund(db, s.pid!, room));
      room.players = room.players.filter((s) => !stale.includes(s));
      if (!room.players.length) delete db.rooms[room.code]; else if (stale.some((s) => s.pid === room.hostId)) room.hostId = room.players[0].pid!;
    }
  });
}
export async function settleRoom(c: string) {
  await transact((db) => {
    const r = db.rooms[c];
    if (!r || r.status !== "running" || r.settled || Date.now() < roomEnd(r)) return;
    const totals = r.players.map((_, i) => r.rounds!.reduce((a, rd) => a + rd[i].value, 0));
    const teamTotals = new Map<number, number>();
    r.players.forEach((s, i) => teamTotals.set(TEAM(r.mode, s.slot), (teamTotals.get(TEAM(r.mode, s.slot)) ?? 0) + totals[i]));
    const best = Math.max(...teamTotals.values());
    const tied = [...teamTotals].filter(([, v]) => v === best).map(([k]) => k);
    const winTeam = tied[r.tie % tied.length];
    const winners = r.players.filter((s) => TEAM(r.mode, s.slot) === winTeam);
    const pool = r.rounds!.flatMap((rd) => rd).sort((a, b) => b.value - a.value);
    const prize = pool.reduce((a, d) => a + d.value, 0);
    const humans = winners.filter((w) => w.pid);
    if (humans.length) pool.forEach((d, i) => { const w = humans[i % humans.length], p = db.players[w.pid!]; if (p) p.inventory.unshift(mkItem(d, "battle:" + r.code)); });
    r.players.forEach((s) => {
      const p = s.pid ? db.players[s.pid] : null; if (!p) return;
      norm(p);
      const won = winners.includes(s);
      p.stats.battles++; p.day.battles++;
      if (won) { p.stats.wins++; p.day.wins++; p.season.wins++; addTx(p, "battle", 0, `Победа в баттле ${r.code}: +${fmt(prize / humans.length)} в предметах`); addTx(p, "bonus", 250, "Бонус за победу в баттле"); }
      else { p.stats.losses++; addTx(p, "battle", 0, `Поражение в баттле ${r.code}`); }
      addTx(p, "bonus", 50, "Бонус за участие в баттле");
      if (won) feed(db, p, pool[0], "Баттл");
    });
    r.status = "finished"; r.settled = true; r.winners = winners.map((w) => w.slot); r.totals = totals; r.prize = prize;
    const fin = Object.values(db.rooms).filter((x) => x.status === "finished").sort((a, b) => (b.startedAt ?? 0) - (a.startedAt ?? 0));
    fin.slice(150).forEach((x) => delete db.rooms[x.code]);
  });
}
export async function rematch(c: string): Promise<string> {
  return transact((db) => {
    const old = db.rooms[c] ?? fail("Комната не найдена"), p = me(db);
    if (old.rematch && db.rooms[old.rematch]?.status === "waiting") {
      const r = db.rooms[old.rematch];
      if (r.players.some((s) => s.pid === p.id)) return r.code;
      pay(db, p, r);
      const slot = Array.from({ length: r.size }, (_, i) => i).find((i) => !r.players.some((s) => s.slot === i)) ?? fail("Комната заполнена");
      r.players.push(slotFor(p, slot)); r.players.sort((a, b) => a.slot - b.slot);
      if (r.players.length === r.size) startRoom(r);
      return r.code;
    }
    const r: Room = { ...old, code: code(), status: "waiting", players: [slotFor(p, 0)], created: Date.now(), hostId: p.id, startedAt: undefined, rounds: undefined, winners: undefined, totals: undefined, settled: false, rematch: undefined, prize: undefined, tie: 0 };
    pay(db, p, r);
    if (r.botsMode) { fillBots(r); startRoom(r); }
    db.rooms[r.code] = r; old.rematch = r.code;
    return r.code;
  });
}
export const allSkins = SKINS;
