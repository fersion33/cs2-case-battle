import { SKINS, SKIN_BY_ID, type Skin, type RarityKey } from "./skins";

export const RARITY: Record<RarityKey, { label: string; color: string; weight: number }> = {
  common: { label: "Ширпотреб", color: "#8b95a7", weight: 48 },
  milspec: { label: "Армейское", color: "#4b7bff", weight: 30 },
  restricted: { label: "Запрещённое", color: "#8d5bff", weight: 13 },
  classified: { label: "Засекреченное", color: "#e04bd8", weight: 5.5 },
  covert: { label: "Тайное", color: "#ff3d4f", weight: 2.4 },
  gold: { label: "Редкий особый", color: "#ffc83d", weight: 1.1 },
  ultra: { label: "Ultra Rare", color: "#ff8a3d", weight: 0.04 },
};

export const WEAR_STEPS = [
  { key: "FN", label: "Factory New", max: 0.07, mult: 1.18 },
  { key: "MW", label: "Minimal Wear", max: 0.15, mult: 1.06 },
  { key: "FT", label: "Field-Tested", max: 0.38, mult: 1 },
  { key: "WW", label: "Well-Worn", max: 0.45, mult: 0.9 },
  { key: "BS", label: "Battle-Scarred", max: 1.01, mult: 0.8 },
];
export const wearOf = (f: number) => WEAR_STEPS.find((w) => f < w.max)!;
export const wearRange = (s: Skin) => `${wearOf(s.minFloat).key}–${wearOf(Math.min(s.maxFloat, 1)).key}`;

export type CaseTier = "cheap" | "medium" | "expensive" | "elite" | "premium";
export const CASE_TIERS: Record<CaseTier, { label: string; accent: string }> = {
  cheap: { label: "Дешёвые", accent: "#4b7bff" },
  medium: { label: "Средние", accent: "#8d5bff" },
  expensive: { label: "Дорогие", accent: "#e04bd8" },
  elite: { label: "Элитные", accent: "#ff3d4f" },
  premium: { label: "Премиальные", accent: "#ffc83d" },
};

export interface CaseDef {
  id: string;
  name: string;
  tag: string;
  tier: CaseTier;
  price: number;
  free?: boolean;
  items: { skinId: string; chance: number }[];
  accent: string;
  hero: string;
}

type CaseSeed = {
  id: string;
  name: string;
  tag: string;
  tier: CaseTier;
  price: number;
  hero: string;
  pool: (s: Skin) => boolean;
  free?: boolean;
};

const ids = (...values: string[]) => new Set(values);
const hasId = (...values: string[]) => {
  const set = ids(...values);
  return (s: Skin) => set.has(s.id);
};
const weapon = (...values: string[]) => {
  const set = ids(...values);
  return (s: Skin) => set.has(s.weapon);
};
const type = (...values: string[]) => {
  const set = ids(...values);
  return (s: Skin) => set.has(s.type);
};
const price = (min: number, max: number) => (s: Skin) => s.price >= min && s.price <= max;
const and = (...rules: ((s: Skin) => boolean)[]) => (s: Skin) => rules.every((rule) => rule(s));
const or = (...rules: ((s: Skin) => boolean)[]) => (s: Skin) => rules.some((rule) => rule(s));
const rarity = (...values: RarityKey[]) => {
  const set = new Set<RarityKey>(values);
  return (s: Skin) => set.has(s.rarity);
};

const defs: CaseSeed[] = [
  // Дешёвые
  { id: "daily", name: "Кейс дня", tag: "Бесплатно раз в сутки", tier: "cheap", price: 0, free: true, hero: "glock-18-water-elemental", pool: and(price(60, 1500), (s) => s.rarity !== "gold") },
  { id: "starter", name: "Первый раунд", tag: "Стартовый арсенал", tier: "cheap", price: 100, hero: "galil-ar-eco", pool: price(0, 250) },
  { id: "budget", name: "Экономический бай", tag: "Бюджетный выбор", tier: "cheap", price: 180, hero: "ssg-08-abyss", pool: price(80, 450) },
  { id: "standard", name: "Стандарт CS2", tag: "Оружие на каждый раунд", tier: "cheap", price: 270, hero: "ak-47-elite-build", pool: and(price(100, 900), (s) => s.rarity !== "gold") },
  { id: "pistols", name: "Пистолетный раунд", tag: "Только пистолеты", tier: "cheap", price: 360, hero: "usp-s-cortex", pool: and(type("Пистолет"), price(100, 1300)) },
  { id: "smg", name: "Эко-раш", tag: "ПП и тяжёлое оружие", tier: "cheap", price: 470, hero: "p90-asiimov", pool: and(type("ПП", "Дробовик", "Пулемёт"), price(80, 1500)) },
  { id: "shotgun", name: "Ближний бой", tag: "Дробовики и ПП", tier: "cheap", price: 590, hero: "sawed-off-the-kraken", pool: type("Дробовик", "ПП") },
  { id: "rifle-lite", name: "Винтовочный набор", tag: "Доступные винтовки", tier: "cheap", price: 720, hero: "m4a1-s-cyrex", pool: and(type("Винтовка"), price(60, 1500)) },
  { id: "sniper-lite", name: "Точный выстрел", tag: "Начальная снайперская", tier: "cheap", price: 860, hero: "awp-atheris", pool: and(type("Снайперская"), price(200, 1800)) },
  { id: "military", name: "Синий контракт", tag: "Армейское и запрещённое", tier: "cheap", price: 990, hero: "mp9-hot-rod", pool: and(rarity("common", "milspec", "restricted"), price(0, 17000)) },

  // Средние
  { id: "ak", name: "AK-47 Легенды", tag: "Калашниковы", tier: "medium", price: 1250, hero: "ak-47-slate", pool: and(weapon("AK-47"), price(500, 7000)) },
  { id: "m4", name: "M4 Дуэль", tag: "M4A4 против M4A1-S", tier: "medium", price: 1480, hero: "m4a4-desolate-space", pool: and(weapon("M4A4", "M4A1-S"), price(1000, 9000)) },
  { id: "awp", name: "AWP Снайпер", tag: "Большая зелёная", tier: "medium", price: 1760, hero: "awp-redline", pool: and(weapon("AWP"), price(250, 10000)) },
  { id: "deagle", name: "Desert Eagle Vault", tag: "Сила одного выстрела", tier: "medium", price: 2100, hero: "desert-eagle-hypnotic", pool: weapon("Desert Eagle") },
  { id: "glock", name: "Glock Rush", tag: "Коллекция Glock-18", tier: "medium", price: 2470, hero: "glock-18-vogue", pool: weapon("Glock-18") },
  { id: "usp", name: "Тихий агент", tag: "Коллекция USP-S", tier: "medium", price: 2890, hero: "usp-s-orion", pool: weapon("USP-S") },
  { id: "smg-pro", name: "Неоновый штурм", tag: "Редкие ПП", tier: "medium", price: 3340, hero: "mac-10-neon-rider", pool: type("ПП") },
  { id: "scout", name: "Разведчик", tag: "SSG 08 и лёгкие AWP", tier: "medium", price: 3820, hero: "ssg-08-dragonfire", pool: or(weapon("SSG 08"), and(weapon("AWP"), price(0, 5200))) },
  { id: "classified", name: "Розовый допуск", tag: "Засекреченные предметы", tier: "medium", price: 4310, hero: "m4a1-s-decimator", pool: and(rarity("classified"), price(100, 7000)) },
  { id: "neon", name: "Neon District", tag: "Яркие городские скины", tier: "medium", price: 4870, hero: "ak-47-neon-revolution", pool: hasId("ak-47-neon-revolution", "glock-18-neo-noir", "usp-s-neo-noir", "awp-neo-noir", "m4a4-neo-noir", "mac-10-neon-rider", "m4a1-s-decimator", "p90-death-by-kitty") },

  // Дорогие
  { id: "premium", name: "Красная линия", tag: "Тайные предметы", tier: "expensive", price: 5650, hero: "ak-47-redline", pool: and(price(1500, 40000), (s) => s.rarity !== "gold") },
  { id: "knife-lite", name: "Первый клинок", tag: "Шанс на нож", tier: "expensive", price: 6900, hero: "huntsman-knife-slaughter", pool: or(and(type("Нож"), price(20000, 65000)), and(rarity("covert"), price(3000, 15000))) },
  { id: "gloves-lite", name: "Перчаточный дроп", tag: "Шанс на перчатки", tier: "expensive", price: 8350, hero: "bloodhound-gloves-charred", pool: or(and(type("Перчатки"), price(20000, 70000)), and(rarity("covert"), price(3000, 15000))) },
  { id: "rare", name: "Редкий резерв", tag: "Предметы от 20 000", tier: "expensive", price: 9900, hero: "m4a4-poseidon", pool: price(20000, 110000) },
  { id: "secret", name: "Секретный контейнер", tag: "Красное и золотое", tier: "expensive", price: 11800, hero: "awp-lightning-strike", pool: and(rarity("covert", "gold", "classified", "ultra"), price(4000, 100000)) },
  { id: "dragon", name: "Легенды Dragon", tag: "Драконы и мифы", tier: "expensive", price: 13900, hero: "ak-47-fire-serpent", pool: hasId("awp-dragon-lore", "ak-47-wild-lotus", "m4a4-howl", "awp-gungnir", "ak-47-fire-serpent", "awp-medusa", "m4a4-poseidon", "ssg-08-dragonfire", "sawed-off-the-kraken") },
  { id: "printstream", name: "Белый шум", tag: "Printstream и монохром", tier: "expensive", price: 16400, hero: "desert-eagle-printstream", pool: hasId("desert-eagle-printstream", "m4a1-s-printstream", "usp-s-printstream", "ak-47-slate", "m4a1-s-mecha-industries", "desert-eagle-mecha-industries", "m4a4-desolate-space") },
  { id: "asiimov", name: "Asiimov Protocol", tag: "Научная фантастика", tier: "expensive", price: 19200, hero: "awp-asiimov", pool: hasId("awp-asiimov", "ak-47-asiimov", "m4a4-asiimov", "p250-asiimov", "p90-asiimov", "m4a1-s-mecha-industries", "desert-eagle-mecha-industries") },
  { id: "doppler", name: "Doppler Core", tag: "Хроматический шанс", tier: "expensive", price: 22400, hero: "flip-knife-doppler", pool: or((s) => s.skin.includes("Doppler"), hasId("awp-lightning-strike", "glock-18-fade", "r8-revolver-fade")) },
  { id: "fire", name: "Огненный шторм", tag: "Красные и пламенные", tier: "expensive", price: 25800, hero: "m4a1-s-chantico-s-fire", pool: hasId("ak-47-fire-serpent", "m4a4-howl", "desert-eagle-blaze", "desert-eagle-code-red", "m4a1-s-chantico-s-fire", "p2000-fire-elemental", "ssg-08-dragonfire", "ak-47-bloodsport") },

  // Элитные
  { id: "knife", name: "Золотой клинок", tag: "Коллекция ножей", tier: "elite", price: 31500, hero: "bayonet-marble-fade", pool: type("Нож") },
  { id: "gloves", name: "Золотые перчатки", tag: "Все типы перчаток", tier: "elite", price: 37800, hero: "hand-wraps-cobalt-skulls", pool: type("Перчатки") },
  { id: "awp-elite", name: "AWP Элита", tag: "Коллекционные AWP", tier: "elite", price: 44600, hero: "awp-fade", pool: and(weapon("AWP"), price(30000, 700000)) },
  { id: "ak-elite", name: "AK Crown", tag: "Элитные AK-47", tier: "elite", price: 51900, hero: "ak-47-vulcan", pool: and(weapon("AK-47"), price(4000, 500000)) },
  { id: "m4-elite", name: "M4 Command", tag: "Элитные M4", tier: "elite", price: 59700, hero: "m4a1-s-golden-coil", pool: and(weapon("M4A4", "M4A1-S"), price(3000, 400000)) },
  { id: "fade", name: "Fade Spectrum", tag: "Все оттенки Fade", tier: "elite", price: 68200, hero: "talon-knife-fade", pool: or((s) => s.skin.includes("Fade"), (s) => s.skin.includes("Doppler")) },
  { id: "case-hardened", name: "Case Hardened Lab", tag: "Закалённые паттерны", tier: "elite", price: 77300, hero: "hydra-gloves-case-hardened", pool: or((s) => s.skin.includes("Case Hardened"), and(rarity("gold"), price(30000, 140000))) },
  { id: "crimson", name: "Crimson Strike", tag: "Красная коллекция", tier: "elite", price: 87100, hero: "skeleton-knife-crimson-web", pool: hasId("skeleton-knife-crimson-web", "specialist-gloves-crimson-kimono", "desert-eagle-code-red", "usp-s-kill-confirmed", "ak-47-bloodsport", "ak-47-redline", "awp-redline", "huntsman-knife-slaughter") },
  { id: "collector", name: "Коллекционер", tag: "Редкие легендарные", tier: "elite", price: 97600, hero: "driver-gloves-king-snake", pool: price(38000, 190000) },
  { id: "mythic", name: "Mythic Vault", tag: "Мифы высшего класса", tier: "elite", price: 108900, hero: "moto-gloves-spearmint", pool: or(and(type("Нож", "Перчатки"), price(40000, 200000)), and(rarity("covert"), price(90000, 500000))) },

  // Премиальные
  { id: "butterfly", name: "Butterfly Royale", tag: "Бабочки премиум-класса", tier: "premium", price: 124000, hero: "butterfly-knife-doppler", pool: or(weapon("Butterfly Knife"), and(type("Нож"), price(85000, 300000))) },
  { id: "karambit", name: "Karambit Dynasty", tag: "Изогнутые клинки", tier: "premium", price: 142000, hero: "karambit-doppler", pool: or(weapon("Karambit"), and(type("Нож"), price(90000, 300000))) },
  { id: "sport-gloves", name: "Sport Gloves Arena", tag: "Перчатки спортсмена", tier: "premium", price: 163000, hero: "sport-gloves-vice", pool: or(weapon("Sport Gloves"), and(type("Перчатки"), price(70000, 600000))) },
  { id: "specialist-gloves", name: "Specialist Unit", tag: "Перчатки спецназа", tier: "premium", price: 187000, hero: "specialist-gloves-crimson-kimono", pool: or(weapon("Specialist Gloves"), and(type("Перчатки"), price(160000, 600000))) },
  { id: "dragon-lore", name: "Dragon Lore Vault", tag: "Наследие Cobblestone", tier: "premium", price: 216000, hero: "awp-dragon-lore", pool: hasId("awp-dragon-lore", "awp-gungnir", "awp-medusa", "ak-47-wild-lotus", "m4a4-howl", "sport-gloves-pandora-s-box") },
  { id: "gungnir", name: "Gungnir Ascension", tag: "Северная коллекция", tier: "premium", price: 249000, hero: "awp-gungnir", pool: hasId("awp-gungnir", "awp-dragon-lore", "awp-medusa", "ak-47-wild-lotus", "karambit-fade", "butterfly-knife-fade") },
  { id: "wild-lotus", name: "Wild Lotus Garden", tag: "Экзотическая коллекция", tier: "premium", price: 287000, hero: "ak-47-wild-lotus", pool: hasId("ak-47-wild-lotus", "awp-dragon-lore", "awp-gungnir", "m4a4-howl", "sport-gloves-vice", "moto-gloves-spearmint") },
  { id: "howl", name: "Howl Contraband", tag: "Контрабандная коллекция", tier: "premium", price: 329000, hero: "m4a4-howl", pool: hasId("m4a4-howl", "awp-dragon-lore", "ak-47-wild-lotus", "awp-gungnir", "specialist-gloves-crimson-kimono", "karambit-fade") },
  { id: "royal", name: "Royal Arsenal", tag: "Королевский резерв", tier: "premium", price: 378000, hero: "karambit-fade", pool: or(and(type("Нож", "Перчатки"), price(140000, 600000)), and(rarity("covert"), price(300000, 700000))) },
  { id: "pandora", name: "Pandora's Fortune", tag: "Абсолютный джекпот", tier: "premium", price: 435000, hero: "sport-gloves-pandora-s-box", pool: or(price(190000, 700000), rarity("ultra")) },
];

function build(seed: CaseSeed): CaseDef {
  const pool = SKINS.filter(seed.pool);
  const hero = SKIN_BY_ID[seed.hero];
  if (!hero) throw new Error(`Обложка кейса ${seed.id} не найдена`);
  if (!pool.some((skin) => skin.id === hero.id)) pool.push(hero);
  if (!pool.length) throw new Error(`Кейс ${seed.id} не содержит предметов`);

  const tiers = new Map<RarityKey, Skin[]>();
  pool.forEach((skin) => tiers.set(skin.rarity, [...(tiers.get(skin.rarity) ?? []), skin]));
  const totalWeight = [...tiers.keys()].reduce((sum, key) => sum + RARITY[key].weight, 0);
  const items = pool.map((skin) => ({
    skinId: skin.id,
    chance: (RARITY[skin.rarity].weight / totalWeight / tiers.get(skin.rarity)!.length) * 100,
  }));

  return {
    id: seed.id,
    name: seed.name,
    tag: seed.tag,
    tier: seed.tier,
    price: seed.price,
    free: seed.free,
    items,
    accent: CASE_TIERS[seed.tier].accent,
    hero: seed.hero,
  };
}

export const CASES: CaseDef[] = defs.map(build);
if (CASES.length !== 50 || new Set(CASES.map((c) => c.id)).size !== 50) {
  throw new Error("Каталог должен содержать ровно 50 уникальных кейсов");
}
if (new Set(CASES.map((c) => c.hero)).size !== 50 || new Set(CASES.map((c) => c.price)).size !== 50) {
  throw new Error("У каждого кейса должны быть уникальные обложка и цена");
}
export const CASE_BY_ID: Record<string, CaseDef> = Object.fromEntries(CASES.map((c) => [c.id, c]));
