import { CASES, CASE_BY_ID } from "../data/cases";
import { SKIN_BY_ID } from "../data/skins";
import { DAILY_REWARDS, QUESTS, claimDaily, claimQuest, dailyState, dismissInvite, fmt, invValue, questKey, useMe, useDB, joinRoom } from "../lib/engine";
import { Btn, Money, SkinImg, rc, toast, toastErr, cx, Avatar } from "../lib/ui";
import { CaseCard } from "./Cases";

export default function Home({ go }: { go: (p: string) => void }) {
  const p = useMe(), db = useDB();
  const ds = dailyState(p), today = new Date().toISOString().slice(0, 10);
  const daily = CASE_BY_ID.daily, freeUsed = p.daily.freeCase === today;
  const dq = QUESTS.filter((q) => q.period === "daily");
  const claim = async () => { try { toast(`+${fmt(await claimDaily())} монет`); } catch (e) { toastErr(e); } };
  return (
    <div className="pb-6">
      <div className="px-4 pt-5">
        <div className="flex items-center gap-3">
          <button onClick={() => go("/profile")}><Avatar idx={p.avatar} nick={p.nick} size={44} /></button>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] uppercase tracking-widest text-white/40">Добро пожаловать</div>
            <div className="truncate font-display text-xl font-bold leading-tight">{p.nick}</div>
          </div>
          <div className="hud bg-panel2 px-3 py-2 text-right">
            <div className="text-[9px] uppercase tracking-widest text-white/40">Баланс</div>
            <Money n={p.balance} className="text-base text-gold" />
          </div>
        </div>
        <div className="hud relative mt-4 overflow-hidden border border-line bg-gradient-to-br from-[#2a1a5e] via-[#14112b] to-panel p-4">
          <div className="absolute -right-6 -top-6 h-40 w-40 rounded-full bg-violet/30 blur-3xl" />
          <div className="font-display text-[11px] uppercase tracking-[.3em] text-gold">CS2 Case Battle</div>
          <div className="mt-1 font-display text-3xl font-bold uppercase leading-[0.95]">Открывай.<br />Сражайся.<br /><span className="text-violet">Побеждай.</span></div>
          <div className="relative mt-4 grid grid-cols-3 gap-2 text-center">
            {[["Инвентарь", fmt(invValue(p))], ["Кейсов", p.stats.cases], ["Побед", p.stats.wins]].map(([l, v]) => (
              <div key={l} className="bg-black/40 px-2 py-2"><div className="font-mono text-sm font-bold">{v}</div><div className="text-[9px] uppercase tracking-wider text-white/40">{l}</div></div>
            ))}
          </div>
        </div>
      </div>

      {p.invites.map((i) => (
        <div key={i.room} className="rise mx-4 mt-3 flex items-center gap-3 border border-violet/50 bg-violet/10 p-3">
          <div className="flex-1 text-sm"><b>{i.from}</b> зовёт в баттл <span className="font-mono">{i.room}</span></div>
          <Btn tone="violet" className="!px-3 !py-2" onClick={async () => { try { await joinRoom(i.room); go("/room/" + i.room); } catch (e) { toastErr(e); } }}>Войти</Btn>
          <button className="text-white/40" onClick={() => dismissInvite(i.room)}>×</button>
        </div>
      ))}

      <Section title="Ежедневная награда" sub={`Серия: ${ds.streak} дн.`}>
        <div className="grid grid-cols-7 gap-1">
          {DAILY_REWARDS.map((r, i) => {
            const claimed = ds.canClaim ? i < ds.streak % 7 && ds.streak % 7 !== 0 : i < ((ds.streak - 1) % 7) + 1;
            const next = ds.canClaim && i === ds.streak % 7;
            return (
              <div key={i} className={cx("hud flex flex-col items-center py-2 text-center", claimed ? "bg-violet/25 text-white/50" : next ? "glow bg-gold/15" : "bg-panel2")} style={{ ["--c" as string]: "#ffc83d" }}>
                <div className="text-[9px] text-white/40">Д{i + 1}</div>
                <div className={cx("font-mono text-[11px] font-bold", next && "text-gold")}>{r >= 1000 ? r / 1000 + "k" : r}</div>
                <div className="text-xs">{claimed ? "✓" : ""}</div>
              </div>
            );
          })}
        </div>
        <Btn tone="gold" className="mt-3 w-full" disabled={!ds.canClaim} onClick={claim}>{ds.canClaim ? "Забрать награду" : "Награда получена — приходи завтра"}</Btn>
      </Section>

      <Section title="Кейс дня" sub="Бесплатно раз в сутки">
        <button onClick={() => go("/case/daily")} className="hud rar-bg glow relative flex w-full items-center gap-3 border border-gold/40 p-3 text-left" style={{ ["--c" as string]: "#ffc83d" }}>
          <SkinImg skin={SKIN_BY_ID[daily.hero]} className="floaty h-20 w-28" />
          <div className="flex-1">
            <div className="font-display text-xl font-bold uppercase">{daily.name}</div>
            <div className="text-xs text-white/60">{freeUsed ? "Уже открыт сегодня" : "Открой бесплатно прямо сейчас"}</div>
            <div className={cx("mt-2 inline-block px-2 py-0.5 text-[10px] font-bold uppercase", freeUsed ? "bg-white/10 text-white/50" : "bg-gold text-black pulse-s")}>{freeUsed ? "Завтра снова" : "FREE"}</div>
          </div>
        </button>
      </Section>

      <Section title="Популярные кейсы" action={<button className="text-xs text-violet" onClick={() => go("/cases")}>Все →</button>}>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {CASES.filter((c) => ["ak", "awp", "knife-lite", "premium", "dragon"].includes(c.id)).map((c) => <div key={c.id} className="w-40 shrink-0 sm:w-48"><CaseCard c={c} onClick={() => go("/case/" + c.id)} /></div>)}
        </div>
      </Section>

      <Section title="Быстрый старт">
        <div className="grid grid-cols-2 gap-2">
          {[["⚔", "Баттл", "/battles", "#ff3d4f"], ["⬆", "Апгрейд", "/upgrade", "#8d5bff"], ["▣", "Инвентарь", "/profile", "#4b7bff"], ["★", "Задания", "/profile?tab=quests", "#ffc83d"]].map(([i, l, to, c]) => (
            <button key={l} onClick={() => go(to)} style={{ ["--c" as string]: c }} className="hud rar-bg flex items-center gap-3 border border-line p-3 text-left font-display text-base font-bold uppercase"><span className="text-xl" style={{ color: c }}>{i}</span>{l}</button>
          ))}
        </div>
      </Section>

      <Section title="Задания дня">
        <div className="space-y-2">
          {dq.map((q) => {
            const v = Math.min(q.prog(p), q.goal), done = v >= q.goal, got = p.claimed[q.id] === questKey(q);
            return (
              <div key={q.id} className="flex items-center gap-3 bg-panel2 p-3">
                <div className="min-w-0 flex-1"><div className="text-sm font-semibold">{q.title}</div><div className="mt-1.5 h-1 bg-black"><div className="h-full bg-violet" style={{ width: (v / q.goal) * 100 + "%" }} /></div></div>
                {got ? <span className="text-xs text-white/40">Получено</span> : <Btn tone={done ? "gold" : "ghost"} disabled={!done} className="!px-3 !py-2 !text-[11px]" onClick={async () => { try { toast(`+${fmt(await claimQuest(q.id))}`); } catch (e) { toastErr(e); } }}>{fmt(q.reward)}</Btn>}
              </div>
            );
          })}
        </div>
      </Section>

      <Section title="Живая лента">
        <div className="space-y-1.5">
          {db.feed.length === 0 && <div className="text-sm text-white/40">Пока пусто — открой первый кейс.</div>}
          {db.feed.slice(0, 6).map((f, i) => {
            const s = SKIN_BY_ID[f.skinId];
            return (
              <div key={i} className="flex items-center gap-3 border-l-2 bg-panel2 py-1.5 pl-2 pr-3" style={{ borderColor: rc(s) }}>
                <SkinImg skin={s} className="h-9 w-14" />
                <div className="min-w-0 flex-1 text-xs"><b>{f.nick}</b> · {f.src}<div className="truncate text-white/50">{s.name}</div></div>
                <Money n={f.value} className="text-xs text-gold" />
              </div>
            );
          })}
        </div>
      </Section>
    </div>
  );
}

function Section({ title, sub, action, children }: { title: string; sub?: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="mt-6 px-4">
      <div className="mb-2.5 flex items-end justify-between">
        <div><div className="font-display text-lg font-bold uppercase leading-none">{title}</div>{sub && <div className="mt-1 text-[11px] text-white/40">{sub}</div>}</div>
        {action}
      </div>
      {children}
    </div>
  );
}
