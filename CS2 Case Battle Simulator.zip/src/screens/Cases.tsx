import { useMemo, useRef, useState } from "react";
import { CASES, CASE_BY_ID, CASE_TIERS, RARITY, wearRange, type CaseDef, type CaseTier } from "../data/cases";
import { SKINS, SKIN_BY_ID, type RarityKey, type Skin } from "../data/skins";
import { openCase, sellItems, useMe, type Item, fmt, wearLabel } from "../lib/engine";
import { Btn, Header, Money, Roller, SkinCard, SkinImg, Tabs, cx, rc, toast, toastErr } from "../lib/ui";

export function CaseCard({ c, onClick }: { c: CaseDef; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ ["--c" as string]: c.accent }} className="rar-bg hud relative flex w-full flex-col overflow-hidden border border-line text-left transition active:scale-[.97]">
      <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: c.accent }} />
      <div className="relative">
        <div className="absolute inset-0 opacity-60" style={{ background: `radial-gradient(60% 60% at 50% 55%, ${c.accent}55, transparent)` }} />
        <SkinImg skin={SKIN_BY_ID[c.hero]} className="relative mx-auto h-24 w-full px-3 pt-3" />
      </div>
      <div className="p-2.5 pt-1">
        <div className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: c.accent }}>{CASE_TIERS[c.tier].label} · {c.tag}</div>
        <div className="truncate font-display text-[15px] font-bold uppercase leading-tight">{c.name}</div>
        {c.free ? <span className="mt-1 inline-block bg-gold px-1.5 text-[11px] font-bold text-black">FREE</span> : <Money n={c.price} className="mt-1 text-[13px] text-gold" />}
      </div>
    </button>
  );
}

export default function Cases({ go }: { go: (p: string) => void }) {
  const [tab, setTab] = useState<"cases" | "catalog">("cases");
  const [sort, setSort] = useState<"price" | "cheap">("cheap");
  const [q, setQ] = useState("");
  const [tier, setTier] = useState<CaseTier | "all">("all");
  const [rarity, setRarity] = useState<RarityKey | "all">("all");
  const list = useMemo(() => CASES
    .filter((c) => c.name.toLowerCase().includes(q.trim().toLowerCase()))
    .filter((c) => tier === "all" || c.tier === tier)
    .filter((c) => rarity === "all" || c.items.some((item) => SKIN_BY_ID[item.skinId].rarity === rarity))
    .sort((a, b) => (sort === "cheap" ? a.price - b.price : b.price - a.price)), [q, tier, rarity, sort]);
  return (
    <div className="pb-6">
      <Header title="Кейсы" sub={`${CASES.length} кейсов · ${SKINS.length} скинов`} />
      <Tabs value={tab} onChange={setTab} items={[["cases", "Кейсы"], ["catalog", "Каталог скинов"]]} />
      {tab === "cases" ? (
        <>
          <div className="space-y-2 px-4 pb-3">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Найти кейс…" className="w-full border border-line bg-panel2 px-3 py-2.5 text-sm outline-none focus:border-violet" />
            <div className="flex gap-1.5 overflow-x-auto">
              <button onClick={() => setTier("all")} className={cx("shrink-0 px-3 py-1.5 text-xs", tier === "all" ? "bg-white font-bold text-black" : "bg-panel2 text-white/55")}>Все цены</button>
              {(Object.keys(CASE_TIERS) as CaseTier[]).map((key) => <button key={key} onClick={() => setTier(key)} className={cx("shrink-0 px-3 py-1.5 text-xs", tier === key ? "bg-white font-bold text-black" : "bg-panel2")} style={tier === key ? undefined : { color: CASE_TIERS[key].accent }}>{CASE_TIERS[key].label}</button>)}
            </div>
            <div className="flex gap-1.5 overflow-x-auto">
              <button onClick={() => setRarity("all")} className={cx("shrink-0 px-3 py-1.5 text-xs", rarity === "all" ? "bg-white font-bold text-black" : "bg-panel2 text-white/55")}>Любая редкость</button>
              {(Object.keys(RARITY) as RarityKey[]).map((key) => <button key={key} onClick={() => setRarity(key)} className={cx("shrink-0 px-3 py-1.5 text-xs", rarity === key ? "bg-white font-bold text-black" : "bg-panel2")} style={rarity === key ? undefined : { color: RARITY[key].color }}>{RARITY[key].label}</button>)}
            </div>
            <div className="flex items-center gap-2 text-xs">
              {([["cheap", "Сначала дешёвые"], ["price", "Сначала дорогие"]] as const).map(([key, label]) => (
                <button key={key} onClick={() => setSort(key)} className={cx("px-3 py-1.5", sort === key ? "bg-violet text-white" : "bg-panel2 text-white/50")}>{label}</button>
              ))}
              <span className="ml-auto text-white/40">{list.length} из 50</span>
            </div>
          </div>
          {list.length === 0 ? <div className="px-4 py-12 text-center text-sm text-white/40">Кейсы по этим фильтрам не найдены.</div> : <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 lg:grid-cols-4">{list.map((c) => <CaseCard key={c.id} c={c} onClick={() => go("/case/" + c.id)} />)}</div>}
        </>
      ) : <Catalog />}
    </div>
  );
}

export function Catalog({ onPick, minPrice = 0, embedded }: { onPick?: (s: Skin) => void; minPrice?: number; embedded?: boolean }) {
  const [q, setQ] = useState(""), [type, setType] = useState("all"), [rar, setRar] = useState<RarityKey | "all">("all"), [price, setPrice] = useState("all"), [sort, setSort] = useState("pd");
  const [detail, setDetail] = useState<Skin | null>(null);
  const types = ["all", ...new Set(SKINS.map((s) => s.type))];
  const ranges: Record<string, [number, number]> = { all: [0, 5_000_001], a: [0, 1000], b: [1000, 10000], c: [10000, 100000], d: [100000, 1_000_000], e: [1_000_000, 5_000_001] };
  const rows = useMemo(() => SKINS.filter((s) => s.price >= minPrice && s.name.toLowerCase().includes(q.toLowerCase()) && (type === "all" || s.type === type) && (rar === "all" || s.rarity === rar) && s.price >= ranges[price][0] && s.price < ranges[price][1]).sort((a, b) => (sort === "pd" ? b.price - a.price : sort === "pa" ? a.price - b.price : a.name.localeCompare(b.name))), [q, type, rar, price, sort, minPrice]);
  const chip = (on: boolean) => cx("shrink-0 px-3 py-1.5 text-xs", on ? "bg-white text-black font-bold" : "bg-panel2 text-white/55");
  return (
    <div>
      <div className="space-y-2 px-4 pb-3">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию…" className="w-full border border-line bg-panel2 px-3 py-2.5 text-sm outline-none focus:border-violet" />
        <div className="flex gap-1.5 overflow-x-auto">{types.map((t) => <button key={t} onClick={() => setType(t)} className={chip(type === t)}>{t === "all" ? "Всё оружие" : t}</button>)}</div>
        <div className="flex gap-1.5 overflow-x-auto">
          <button onClick={() => setRar("all")} className={chip(rar === "all")}>Любая редкость</button>
          {(Object.keys(RARITY) as RarityKey[]).map((k) => <button key={k} onClick={() => setRar(k)} className={chip(rar === k)} style={rar === k ? undefined : { color: RARITY[k].color }}>{RARITY[k].label}</button>)}
        </div>
        <div className="flex gap-1.5 overflow-x-auto">
          {[["all", "Любая цена"], ["a", "< 1k"], ["b", "1k–10k"], ["c", "10k–100k"], ["d", "100k–1M"], ["e", "1M–5M"]].map(([k, l]) => <button key={k} onClick={() => setPrice(k)} className={chip(price === k)}>{l}</button>)}
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="ml-auto shrink-0 bg-panel2 px-2 text-xs text-white/70">
            <option value="pd">Цена ↓</option><option value="pa">Цена ↑</option><option value="n">Название</option>
          </select>
        </div>
      </div>
      <div className="px-4 pb-2 text-xs text-white/40">Найдено: {rows.length}</div>
      <div className={cx("grid gap-3 px-4", embedded ? "grid-cols-2" : "grid-cols-2")}>
        {rows.map((s) => <SkinCard key={s.id} skin={s} wear={wearRange(s)} onClick={() => (onPick ? onPick(s) : setDetail(s))} />)}
      </div>
      {detail && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/70" onClick={() => setDetail(null)}>
          <div className="rise rar-bg mx-auto w-full max-w-md border-t p-4" style={{ ["--c" as string]: rc(detail), borderColor: rc(detail) }} onClick={(e) => e.stopPropagation()}>
            <SkinImg skin={detail} className="mx-auto h-40 w-full" />
            <div className="text-xs font-bold uppercase" style={{ color: rc(detail) }}>{RARITY[detail.rarity].label} · {detail.quality} · {detail.type}</div>
            <div className="font-display text-2xl font-bold">{detail.name}</div>
            <div className="mt-2 flex items-center justify-between text-sm text-white/60"><span>Износ: {wearRange(detail)}</span><Money n={detail.price} className="text-gold" /></div>
            <div className="mt-3 text-xs text-white/40">Кейсы с этим скином: {CASES.filter((c) => c.items.some((i) => i.skinId === detail.id)).map((c) => c.name).join(", ") || "—"}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export function CaseView({ id, go }: { id: string; go: (p: string) => void }) {
  const c = CASE_BY_ID[id], p = useMe();
  const [res, setRes] = useState<{ item: Item; startAt: number } | null>(null);
  const [done, setDone] = useState(false), [busy, setBusy] = useState(false), [skip, setSkip] = useState(0);
  const reqId = useRef("");
  if (!c) return <Header title="Кейс не найден" onBack={() => go("/cases")} />;
  const used = c.free && p.daily.freeCase === new Date().toISOString().slice(0, 10);
  const items = [...c.items].sort((a, b) => SKIN_BY_ID[b.skinId].price - SKIN_BY_ID[a.skinId].price);
  const open = async () => {
    setBusy(true); setDone(false); setRes(null);
    reqId.current = reqId.current || Math.random().toString(36).slice(2);
    try {
      const item = await openCase(c.id, reqId.current); // результат уже зафиксирован сервером
      reqId.current = "";
      setSkip(0); setRes({ item, startAt: Date.now() + 250 });
    } catch (e) { toastErr(e); } finally { setBusy(false); }
  };
  const skin = res && SKIN_BY_ID[res.item.skinId];
  const spinning = res && !done;
  return (
    <div className="pb-8">
      <Header title={c.name} sub={c.tag} onBack={() => go("/cases")} right={!c.free && <Money n={p.balance} className="text-sm text-gold" />} />
      <div className="relative" style={{ ["--c" as string]: c.accent }}>
        {res ? (
          <div className="py-4">
            <Roller key={res.startAt + skip} caseId={c.id} seed={res.item.iid} result={{ skinId: res.item.skinId, float: res.item.float, value: res.item.value }} startAt={skip ? 0 : res.startAt} onDone={() => setDone(true)} />
          </div>
        ) : (
          <div className="relative flex h-44 items-center justify-center overflow-hidden">
            <div className="absolute inset-0" style={{ background: `radial-gradient(50% 70% at 50% 55%, ${c.accent}40, transparent)` }} />
            <SkinImg skin={SKIN_BY_ID[c.hero]} className="floaty relative h-36 w-64" />
          </div>
        )}
      </div>

      {done && res && skin ? (
        <div className="pop rar-bg hud glow mx-4 mt-3 border p-4 text-center" style={{ ["--c" as string]: rc(skin), borderColor: rc(skin) }}>
          <div className="text-xs font-bold uppercase tracking-[.25em]" style={{ color: rc(skin) }}>{RARITY[skin.rarity].label}</div>
          <SkinImg skin={skin} className="mx-auto h-36 w-full" />
          <div className="font-display text-2xl font-bold">{skin.name}</div>
          <div className="mt-1 text-xs text-white/50">{wearLabel(res.item.wear)} · float {res.item.float.toFixed(4)}</div>
          <Money n={res.item.value} className="mt-2 text-xl text-gold" />
          <div className="mt-1 text-[11px] text-white/40">Добавлено в инвентарь</div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Btn tone="ghost" onClick={async () => { try { toast(`Продано: +${fmt(await sellItems([res.item.iid]))}`); setRes(null); setDone(false); } catch (e) { toastErr(e); } }}>Продать</Btn>
            <Btn tone="violet" disabled={c.free && true} onClick={open}>Открыть ещё</Btn>
          </div>
        </div>
      ) : (
        <div className="px-4 pt-3">
          {spinning ? (
            <Btn tone="ghost" className="w-full" onClick={() => setSkip(1)}>Пропустить анимацию</Btn>
          ) : (
            <Btn tone={c.free ? "gold" : "violet"} className="w-full !py-4 !text-base" busy={busy} disabled={used || (!c.free && p.balance < c.price)} onClick={open}>
              {used ? "Кейс дня уже открыт сегодня" : c.free ? "Открыть бесплатно" : p.balance < c.price ? "Недостаточно монет" : <>Открыть за {fmt(c.price)}</>}
            </Btn>
          )}
        </div>
      )}

      <div className="mt-6 px-4">
        <div className="mb-2 flex items-end justify-between"><div className="font-display text-lg font-bold uppercase">Содержимое</div><div className="text-[11px] text-white/40">{items.length} предметов · шансы по серверу</div></div>
        <div className="grid grid-cols-2 gap-3">
          {items.map((i) => <SkinCard key={i.skinId} skin={SKIN_BY_ID[i.skinId]} badge={<div className="absolute right-1.5 top-2 bg-black/70 px-1.5 font-mono text-[10px] font-bold">{i.chance < 0.01 ? "<0.01" : i.chance.toFixed(i.chance < 1 ? 3 : 2)}%</div>} />)}
        </div>
      </div>
    </div>
  );
}
