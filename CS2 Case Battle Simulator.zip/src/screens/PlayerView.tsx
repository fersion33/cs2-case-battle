import { SKIN_BY_ID } from "../data/skins";
import { addFriend, fmt, invValue, useDB, useMe } from "../lib/engine";
import { Avatar, Btn, Header, Money, SkinCard, toast, toastErr } from "../lib/ui";

export default function PlayerView({ id, go }: { id: string; go: (p: string) => void }) {
  const db = useDB(), me = useMe(), p = db.players[id];
  if (!p) return <Header title="Игрок не найден" onBack={() => go("/profile")} />;
  const top = [...p.inventory].sort((a, b) => b.value - a.value).slice(0, 6);
  const friend = me.friends.includes(p.id);
  return (
    <div className="pb-8">
      <Header title="Игрок" onBack={() => history.back()} />
      <div className="mx-4 hud border border-line bg-gradient-to-br from-[#221a46] to-panel p-4">
        <div className="flex items-center gap-3"><Avatar idx={p.avatar} nick={p.nick} size={56} /><div className="flex-1"><div className="font-display text-2xl font-bold">{p.nick}</div><div className="font-mono text-xs text-white/50">ID {p.uid}</div></div></div>
        <div className="mt-4 grid grid-cols-3 gap-1.5 text-center">
          {[["Инвентарь", fmt(invValue(p))], ["Кейсов", p.stats.cases], ["Баттлов", p.stats.battles], ["Победы", p.stats.wins], ["Поражения", p.stats.losses], ["Друзей", p.friends.length]].map(([l, v]) => (
            <div key={l} className="bg-black/40 py-2"><div className="font-mono text-sm font-bold">{v}</div><div className="text-[9px] uppercase tracking-wider text-white/40">{l}</div></div>
          ))}
        </div>
        {p.id !== me.id && <Btn tone={friend ? "ghost" : "violet"} className="mt-3 w-full" disabled={friend} onClick={async () => { try { await addFriend(p.uid); toast("Друг добавлен"); } catch (e) { toastErr(e); } }}>{friend ? "В друзьях" : "Добавить в друзья"}</Btn>}
      </div>
      <div className="mt-5 px-4"><div className="mb-2 font-display text-sm font-bold uppercase">Лучшие предметы · <Money n={top.reduce((a, i) => a + i.value, 0)} className="text-gold" /></div>
        <div className="grid grid-cols-2 gap-3">{top.map((i) => <SkinCard key={i.iid} skin={SKIN_BY_ID[i.skinId]} value={i.value} wear={i.wear} />)}</div>
        {!top.length && <div className="text-sm text-white/40">Инвентарь пуст.</div>}
      </div>
    </div>
  );
}
