import { useEffect, useRef, useState } from "react";
import { RARITY } from "../data/cases";
import { SKIN_BY_ID, type Skin } from "../data/skins";
import { doUpgrade, fmt, upgradeChance, upgradeTarget, useMe, type Item, type UpgradeResult } from "../lib/engine";
import { Btn, Header, Money, Sheet, SkinCard, SkinImg, Tabs, cx, rc, toastErr } from "../lib/ui";
import { Catalog } from "./Cases";

const SPIN_MS = { normal: 5600, fast: 950 } as const;

export default function Upgrade() {
  const p = useMe();
  const [srcId, setSrcId] = useState(() => sessionStorage.getItem("upSrc") ?? "");
  const [target, setTarget] = useState<Skin | null>(null);
  const [pick, setPick] = useState<"" | "src" | "dst">("");
  const [rot, setRot] = useState(0), [spinning, setSpinning] = useState(false), [res, setRes] = useState<UpgradeResult | null>(null);
  const [speed, setSpeed] = useState<keyof typeof SPIN_MS>("normal");
  const [tab, setTab] = useState<"up" | "hist">("up");
  const reqId = useRef("");
  const [lock, setLock] = useState<{ src: Item; target: Skin } | null>(null);
  const src = lock?.src ?? p.inventory.find((i) => i.iid === srcId);
  const tSkin = lock?.target ?? target;
  const t = tSkin ? upgradeTarget(tSkin) : null;
  const chance = src && t ? upgradeChance(src.value, t.value) : 0;
  const ok = !!src && !!t && t.value >= src.value * 1.1;
  const setSrc = (i: Item) => { setSrcId(i.iid); sessionStorage.setItem("upSrc", i.iid); setTarget(null); reqId.current = ""; setRes(null); };
  useEffect(() => { reqId.current = ""; }, [srcId, target?.id]);

  const go = async (mode: keyof typeof SPIN_MS) => {
    if (!src || !target || spinning) return;
    const duration = SPIN_MS[mode];
    setRes(null); setSpinning(true); setLock({ src, target });
    reqId.current = reqId.current || Math.random().toString(36).slice(2); // тот же reqId при повторе = тот же результат
    try {
      const r = await doUpgrade(src.iid, target.id, reqId.current); // результат уже зафиксирован до анимации
      // Один roll управляет и серверным исходом, и положением стрелки: сектор успеха = [0, chance).
      setRot((cur) => cur - (cur % 360) + 360 * (mode === "fast" ? 2 : 6) + r.roll * 3.6);
      setTimeout(() => { setRes(r); setSpinning(false); setLock(null); reqId.current = ""; setSrcId(""); setTarget(null); }, duration + 100);
    } catch (e) { setSpinning(false); setLock(null); toastErr(e); }
  };

  const R = 112, C = 2 * Math.PI * (R - 9);
  return (
    <div className="pb-8">
      <Header title="Апгрейд" sub="Рискни предметом ради более дорогого" />
      <Tabs value={tab} onChange={setTab} items={[["up", "Апгрейд"], ["hist", `История · ${p.upgrades.length}`]]} />
      {tab === "up" ? (
        <div className="px-4">
          <div className="grid grid-cols-2 gap-3">
            <Slot label="Ваш предмет" skin={src ? SKIN_BY_ID[src.skinId] : undefined} value={src?.value} onClick={() => !spinning && setPick("src")} />
            <Slot label="Цель" skin={tSkin ?? undefined} value={t?.value} onClick={() => !spinning && src && setPick("dst")} disabled={!src} />
          </div>

          <div className="relative mx-auto my-5 h-[256px] w-[256px]">
            <svg viewBox="0 0 256 256" className="absolute inset-0 -rotate-90">
              <circle cx="128" cy="128" r={R - 9} fill="none" stroke="#2a1218" strokeWidth="18" />
              <circle cx="128" cy="128" r={R - 9} fill="none" stroke={ok ? "#ffc83d" : "#333"} strokeWidth="18" strokeDasharray={`${(C * chance) / 100} ${C}`} className="transition-all duration-500" style={{ filter: ok ? "drop-shadow(0 0 8px #ffc83d)" : undefined }} />
              <circle cx="128" cy="128" r={R - 24} fill="#0b0c11" stroke="#232733" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <div className="font-display text-5xl font-bold">{ok ? chance.toFixed(2).replace(/\.?0+$/, "") : "0"}<span className="text-2xl text-white/50">%</span></div>
              <div className="text-[10px] uppercase tracking-[.25em] text-white/40">шанс успеха</div>
            </div>
            <div className="absolute inset-0" style={{ transform: `rotate(${rot}deg)`, transition: spinning ? `transform ${SPIN_MS[speed]}ms cubic-bezier(.12,.65,.1,1)` : "none" }}>
              <div className="absolute left-1/2 top-0 h-7 w-1.5 -translate-x-1/2 rounded bg-white shadow-[0_0_12px_#fff]" />
              <div className="absolute left-1/2 top-7 h-0 w-0 -translate-x-1/2 border-x-[6px] border-t-[9px] border-x-transparent border-t-white" />
            </div>
          </div>

          <div className="mb-3 bg-panel2 p-3 text-xs text-white/55">
            Успех: исходный предмет списывается, цель добавляется в инвентарь. Неудача: <b className="text-red">исходный предмет сгорает</b>. Золотой сектор — успех, тёмный — неудача.
          </div>
          <div className="mb-3 grid grid-cols-2 gap-2">
            <button disabled={spinning} onClick={() => setSpeed("normal")} className={cx("hud px-3 py-2.5 text-left transition disabled:opacity-40", speed === "normal" ? "border border-gold/50 bg-gold/10" : "border border-line bg-panel2")}>
              <div className="font-display text-xs font-bold uppercase">Обычный</div>
              <div className="text-[10px] text-white/45">Полная анимация · 5.6 сек</div>
            </button>
            <button disabled={spinning} onClick={() => setSpeed("fast")} className={cx("hud px-3 py-2.5 text-left transition disabled:opacity-40", speed === "fast" ? "border border-gold/50 bg-gold/10" : "border border-line bg-panel2")}>
              <div className="font-display text-xs font-bold uppercase">Fast Spin</div>
              <div className="text-[10px] text-white/45">Быстрая прокрутка · 0.95 сек</div>
            </button>
          </div>
          <Btn tone="gold" className="w-full !py-4 !text-base" disabled={!ok || spinning} onClick={() => go(speed)}>{spinning ? speed === "fast" ? "Fast Spin…" : "Вращение…" : !src ? "Выберите предмет" : !target ? "Выберите цель" : speed === "fast" ? "Fast Spin" : "Апгрейд"}</Btn>

          {res && (
            <div className={cx("pop hud mt-4 border p-4 text-center", res.success ? "border-gold bg-gold/10" : "border-red/60 bg-red/10")}>
              <div className={cx("font-display text-3xl font-bold uppercase", res.success ? "text-gold" : "text-red")}>{res.success ? "Успех!" : "Неудача"}</div>
              <div className="mt-1 font-mono text-xs text-white/50">выпало {res.roll.toFixed(2)} · нужно &lt; {res.chance}</div>
              {res.success && res.reward ? <div className="mt-2 text-sm">Получено: <b>{SKIN_BY_ID[res.reward.skinId].name}</b><br /><Money n={res.reward.value} className="text-gold" /></div> : <div className="mt-2 text-sm text-white/60">Потерян: {res.rec.srcName}</div>}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-2 px-4">
          {p.upgrades.length === 0 && <div className="py-10 text-center text-sm text-white/40">Апгрейдов ещё не было.</div>}
          {p.upgrades.map((u) => (
            <div key={u.id} className="bg-panel2 p-3 text-sm" style={{ borderLeft: `3px solid ${u.success ? "#ffc83d" : "#ff3d4f"}` }}>
              <div className="flex justify-between"><b className={u.success ? "text-gold" : "text-red"}>{u.success ? "Успех" : "Неудача"}</b><span className="text-[11px] text-white/40">{new Date(u.at).toLocaleString("ru-RU")}</span></div>
              <div className="mt-1 text-xs text-white/70">{u.srcName} <span className="text-white/30">→</span> {u.targetName}</div>
              <div className="mt-1 font-mono text-[11px] text-white/40">шанс {u.chance}% · выпало {u.roll.toFixed(2)} · {fmt(u.srcValue)} → {fmt(u.targetValue)}</div>
            </div>
          ))}
        </div>
      )}

      <Sheet open={pick === "src"} onClose={() => setPick("")} title="Выберите предмет">
        {p.inventory.length === 0 ? <div className="py-8 text-center text-sm text-white/50">Инвентарь пуст — откройте кейс.</div> : (
          <div className="grid grid-cols-2 gap-2.5">
            {p.inventory.map((i) => <SkinCard key={i.iid} skin={SKIN_BY_ID[i.skinId]} value={i.value} wear={i.wear} selected={i.iid === srcId} onClick={() => { setSrc(i); setPick(""); }} />)}
          </div>
        )}
      </Sheet>
      <Sheet open={pick === "dst"} onClose={() => setPick("")} title="Выберите цель">
        <div className="-mx-4">
          <Catalog embedded minPrice={Math.floor((src?.value ?? 0) * 0.9)} onPick={(s) => { if (upgradeTarget(s).value < (src?.value ?? 0) * 1.1) return toastErr(new Error("Цель должна быть дороже минимум на 10%")); setTarget(s); setPick(""); }} />
        </div>
      </Sheet>
    </div>
  );
}

function Slot({ label, skin, value, onClick, disabled }: { label: string; skin?: Skin; value?: number; onClick: () => void; disabled?: boolean }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{ ["--c" as string]: skin ? rc(skin) : "#333" }} className={cx("rar-bg hud flex h-40 flex-col items-center justify-center border border-dashed p-2 text-center transition active:scale-95", skin ? "border-white/30" : "border-white/15", disabled && "opacity-40")}>
      <div className="text-[10px] uppercase tracking-widest text-white/40">{label}</div>
      {skin ? <>
        <SkinImg skin={skin} className="h-20 w-full" />
        <div className="w-full truncate text-xs font-bold">{skin.name}</div>
        <div className="text-[10px]" style={{ color: rc(skin) }}>{RARITY[skin.rarity].label}</div>
        <Money n={value ?? 0} className="text-xs text-gold" />
      </> : <div className="mt-2 text-4xl text-white/20">+</div>}
    </button>
  );
}
