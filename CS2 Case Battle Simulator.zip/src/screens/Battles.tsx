import { useEffect, useMemo, useState } from "react";
import { CASES, CASE_BY_ID } from "../data/cases";
import { SKIN_BY_ID } from "../data/skins";
import { MODES, TEAM, T_COUNTDOWN, T_ROUND, createRoom, findMatch, fmt, heartbeat, inviteFriend, joinRoom, leaveRoom, rematch, roomCost, roomEnd, settleRoom, useDB, useMe, type Mode, type Room } from "../lib/engine";
import { Avatar, Btn, Header, Money, Roller, SkinImg, Tabs, cx, rc, toast, toastErr, useNow } from "../lib/ui";

const ROLL = 5200;
const link = (c: string) => `${location.origin}${location.pathname}#/room/${c}`;

export default function Battles({ go }: { go: (p: string) => void }) {
  const db = useDB(), p = useMe();
  const [tab, setTab] = useState<"play" | "rooms" | "history">("play");
  const [mode, setMode] = useState<Mode>("1v1");
  const [sel, setSel] = useState<Record<string, number>>({ standard: 3 });
  const [vis, setVis] = useState<"public" | "private">("public");
  const [code, setCode] = useState(""), [busy, setBusy] = useState(false), [searching, setSearching] = useState("");
  const list = useMemo(() => Object.entries(sel).filter(([, n]) => n > 0).flatMap(([id, n]) => Array(n).fill(id) as string[]).sort(), [sel]);
  const cost = list.length ? roomCost(list) : 0;
  const total = list.length;
  const paid = CASES.filter((c) => !c.free);
  const run = async (f: () => Promise<string>) => { setBusy(true); try { go("/room/" + (await f())); } catch (e) { toastErr(e); } finally { setBusy(false); } };
  const bump = (id: string, d: number) => setSel((s) => { const n = Math.max(0, (s[id] ?? 0) + d); if (total + d > 10 && d > 0) { toast("Максимум 10 кейсов", true); return s; } return { ...s, [id]: n }; });

  const open = Object.values(db.rooms).filter((r) => r.status === "waiting" && r.visibility === "public" && !r.botsMode).sort((a, b) => b.created - a.created);
  const mine = Object.values(db.rooms).filter((r) => r.status === "finished" && r.players.some((s) => s.pid === p.id)).sort((a, b) => (b.startedAt ?? 0) - (a.startedAt ?? 0));
  const active = Object.values(db.rooms).find((r) => r.status !== "finished" && r.players.some((s) => s.pid === p.id));

  return (
    <div className="pb-8">
      <Header title="Баттлы" sub="Онлайн-комнаты · реальное время" />
      {active && (
        <button onClick={() => go("/room/" + active.code)} className="hud mx-4 mb-3 flex w-[calc(100%-2rem)] items-center justify-between border border-red/60 bg-red/10 px-3 py-2.5 text-left text-sm">
          <span>Вы в комнате <b className="font-mono">{active.code}</b> · {active.status === "waiting" ? "ожидание" : "идёт баттл"}</span><span className="font-display font-bold text-red">ВЕРНУТЬСЯ ›</span>
        </button>
      )}
      <Tabs value={tab} onChange={setTab} items={[["play", "Играть"], ["rooms", `Комнаты · ${open.length}`], ["history", "История"]]} />

      {tab === "play" && (
        <div className="space-y-5 px-4">
          <div>
            <Label>Режим</Label>
            <div className="grid grid-cols-4 gap-2">
              {(Object.keys(MODES) as Mode[]).map((m) => (
                <button key={m} onClick={() => setMode(m)} className={cx("hud px-1 py-2.5 text-center", mode === m ? "bg-red text-white" : "bg-panel2 text-white/60")}>
                  <div className="font-display text-sm font-bold">{MODES[m].label}</div><div className="text-[9px] uppercase opacity-70">{MODES[m].sub}</div>
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label>Кейсы <span className="text-white/40">· {total}/10</span></Label>
            <div className="space-y-1.5">
              {paid.map((c) => (
                <div key={c.id} className="flex items-center gap-3 bg-panel2 p-2" style={{ borderLeft: `3px solid ${(sel[c.id] ?? 0) > 0 ? c.accent : "transparent"}` }}>
                  <SkinImg skin={SKIN_BY_ID[c.hero]} className="h-9 w-14" />
                  <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{c.name}</div><Money n={c.price} className="text-[11px] text-gold" /></div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => bump(c.id, -1)} className="h-8 w-8 bg-black/40 text-lg">−</button>
                    <span className="w-5 text-center font-mono text-sm">{sel[c.id] ?? 0}</span>
                    <button onClick={() => bump(c.id, 1)} className="h-8 w-8 bg-violet text-lg">+</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="hud flex items-center justify-between bg-panel2 p-3">
            <div><div className="text-[10px] uppercase tracking-widest text-white/40">Взнос с каждого игрока</div><Money n={cost} className="text-lg text-gold" /></div>
            <div className="text-right text-xs text-white/50">Баланс<br /><Money n={p.balance} className="text-white" /></div>
          </div>
          <div className="flex gap-2 text-xs">
            {(["public", "private"] as const).map((v) => <button key={v} onClick={() => setVis(v)} className={cx("flex-1 py-2", vis === v ? "bg-white font-bold text-black" : "bg-panel2 text-white/50")}>{v === "public" ? "Открытая комната" : "По коду / ссылке"}</button>)}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Btn tone="red" busy={busy} disabled={!total} onClick={() => run(() => createRoom({ mode, cases: list, visibility: vis, bots: false }))}>Создать комнату</Btn>
            <Btn tone="violet" busy={busy} disabled={!total} onClick={() => { setSearching(mode); run(() => findMatch(mode, list)).finally(() => setSearching("")); }}>{searching ? "Поиск…" : "Найти соперника"}</Btn>
          </div>
          <div className="flex gap-2">
            <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} maxLength={5} placeholder="КОД КОМНАТЫ" className="min-w-0 flex-1 border border-line bg-panel2 px-3 text-center font-mono tracking-[.3em] outline-none focus:border-violet" />
            <Btn tone="blue" disabled={code.length < 5} onClick={() => run(() => joinRoom(code))}>Войти</Btn>
          </div>
          <div className="border-t border-line pt-4">
            <div className="mb-1 text-xs text-white/40">Отдельный режим — тренировка. Онлайн-баттлы всегда только с живыми игроками.</div>
            <Btn tone="ghost" className="w-full" disabled={!total} busy={busy} onClick={() => run(() => createRoom({ mode, cases: list, visibility: "private", bots: true }))}>Тренировка с ботами</Btn>
          </div>
        </div>
      )}

      {tab === "rooms" && (
        <div className="space-y-2 px-4">
          {open.length === 0 && <div className="py-10 text-center text-sm text-white/40">Открытых комнат нет.<br />Создайте свою — и пригласите друга!</div>}
          {open.map((r) => (
            <div key={r.code} className="flex items-center gap-3 bg-panel2 p-3">
              <div className="flex-1">
                <div className="font-display font-bold">{MODES[r.mode].label} · {r.cases.length} кейс.</div>
                <div className="text-[11px] text-white/50">{r.players.map((s) => s.nick).join(", ")} · {r.players.length}/{r.size}</div>
                <Money n={r.cost} className="text-xs text-gold" />
              </div>
              <Btn tone="red" className="!px-4 !py-2" disabled={r.players.some((s) => s.pid === p.id)} onClick={() => run(() => joinRoom(r.code))}>Войти</Btn>
            </div>
          ))}
        </div>
      )}

      {tab === "history" && (
        <div className="space-y-2 px-4">
          {mine.length === 0 && <div className="py-10 text-center text-sm text-white/40">Вы ещё не играли баттлы.</div>}
          {mine.map((r) => {
            const me = r.players.find((s) => s.pid === p.id)!, won = r.winners?.includes(me.slot);
            return (
              <button key={r.code} onClick={() => go("/room/" + r.code)} className="flex w-full items-center gap-3 bg-panel2 p-3 text-left" style={{ borderLeft: `3px solid ${won ? "#ffc83d" : "#ff3d4f"}` }}>
                <div className="flex-1"><div className="font-display font-bold">{MODES[r.mode].label} · {r.code}</div><div className="text-[11px] text-white/50">{new Date(r.startedAt!).toLocaleString("ru-RU")} · {r.players.map((s) => s.nick).join(" vs ")}</div></div>
                <div className="text-right"><div className={cx("font-display text-sm font-bold", won ? "text-gold" : "text-red")}>{won ? "ПОБЕДА" : "ПОРАЖЕНИЕ"}</div><Money n={r.totals?.[me.slot] ?? 0} className="text-[11px]" /></div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
const Label = ({ children }: { children: React.ReactNode }) => <div className="mb-2 font-display text-sm font-bold uppercase tracking-wider">{children}</div>;

// ---------------- Комната ----------------
export function RoomView({ code, go }: { code: string; go: (p: string) => void }) {
  const db = useDB(), p = useMe(), now = useNow(200);
  const r = db.rooms[code];
  const mineIn = !!r?.players.some((s) => s.pid === p.id);
  useEffect(() => {
    if (!r || !mineIn) return;
    heartbeat(code).catch(() => {});
    const t = setInterval(() => heartbeat(code).catch(() => {}), 5000);
    return () => clearInterval(t);
  }, [code, mineIn, !!r]);
  useEffect(() => {
    if (r?.status === "running" && now >= roomEnd(r)) settleRoom(code).catch(() => {});
  }, [now >= (r?.rounds ? roomEnd(r) : Infinity), r?.status]);

  if (!r) return <div><Header title="Комната" onBack={() => go("/battles")} /><div className="p-8 text-center text-white/50">Комната не найдена или была закрыта.</div></div>;
  if (!mineIn && r.status === "waiting") {
    return (
      <div><Header title={`Комната ${r.code}`} onBack={() => go("/battles")} />
        <div className="space-y-3 px-4"><RoomInfo r={r} /><Btn tone="red" className="w-full" onClick={async () => { try { await joinRoom(code); } catch (e) { toastErr(e); } }}>Присоединиться · {fmt(r.cost)}</Btn></div>
      </div>
    );
  }
  if (r.status === "waiting") return <Lobby r={r} go={go} />;
  return <Arena r={r} now={now} go={go} />;
}

function RoomInfo({ r }: { r: Room }) {
  return (
    <div className="bg-panel2 p-3 text-sm">
      <div className="font-display text-lg font-bold">{MODES[r.mode].label}</div>
      <div className="text-white/50">{r.cases.map((c) => CASE_BY_ID[c].name).join(" · ")}</div>
      <div className="mt-1 flex justify-between"><span>Взнос</span><Money n={r.cost} className="text-gold" /></div>
    </div>
  );
}

function SlotRow({ r, i, now }: { r: Room; i: number; now: number }) {
  const s = r.players.find((x) => x.slot === i);
  const team = r.mode === "2v2" ? (i < 2 ? "Команда A" : "Команда B") : `Слот ${i + 1}`;
  const online = s && (s.bot || now - s.lastSeen < 20000);
  return (
    <div className={cx("hud flex items-center gap-3 border p-3", s ? "border-line bg-panel2" : "border-dashed border-white/15")}>
      {s ? <Avatar idx={s.avatar} nick={s.nick} size={40} /> : <div className="h-10 w-10 animate-pulse rounded-full bg-white/10" />}
      <div className="flex-1"><div className="text-[10px] uppercase tracking-widest text-white/40">{team}</div><div className="font-display font-bold">{s ? s.nick : "Ищем игрока…"}</div></div>
      {s && <span className={cx("flex items-center gap-1.5 text-[11px]", online ? "text-[#3be8a0]" : "text-white/40")}><i className={cx("h-2 w-2 rounded-full", online ? "bg-[#3be8a0]" : "bg-white/30")} />{s.bot ? "бот" : online ? "онлайн" : "переподключение…"}</span>}
    </div>
  );
}

function Lobby({ r, go }: { r: Room; go: (p: string) => void }) {
  const p = useMe(), db = useDB(), now = useNow(2000);
  const friends = p.friends.map((f) => db.players[f]).filter(Boolean);
  const copy = async (t: string) => { try { await navigator.clipboard.writeText(t); toast("Скопировано"); } catch { toast(t); } };
  return (
    <div className="pb-8">
      <Header title={`Комната ${r.code}`} sub={`${MODES[r.mode].label} · ждём игроков ${r.players.length}/${r.size}`} onBack={() => go("/battles")} />
      <div className="space-y-2.5 px-4">
        <RoomInfo r={r} />
        {Array.from({ length: r.size }, (_, i) => <SlotRow key={i} r={r} i={i} now={now} />)}
        <div className="pulse-s py-2 text-center text-xs text-white/50">Баттл начнётся автоматически, когда подключатся все игроки</div>
        <div className="grid grid-cols-2 gap-2">
          <Btn tone="blue" onClick={() => copy(link(r.code))}>Ссылка-приглашение</Btn>
          <Btn tone="ghost" onClick={() => copy(r.code)}>Код: {r.code}</Btn>
        </div>
        {friends.length > 0 && (
          <div><Label>Пригласить друзей</Label>
            {friends.map((f) => <div key={f.id} className="mb-1.5 flex items-center gap-3 bg-panel2 p-2"><Avatar idx={f.avatar} nick={f.nick} size={30} /><div className="flex-1 text-sm">{f.nick}</div><Btn tone="violet" className="!px-3 !py-1.5 !text-[11px]" onClick={async () => { await inviteFriend(f.id, r.code); toast("Приглашение отправлено"); }}>Позвать</Btn></div>)}
          </div>
        )}
        <Btn tone="ghost" className="w-full" onClick={async () => { await leaveRoom(r.code); toast("Взнос возвращён"); go("/battles"); }}>Выйти и вернуть взнос</Btn>
      </div>
    </div>
  );
}

function Arena({ r, now, go }: { r: Room; now: number; go: (p: string) => void }) {
  const p = useMe();
  const start = r.startedAt!, rounds = r.rounds!, n = rounds.length;
  const t = now - start;
  const cur = Math.min(n - 1, Math.max(0, Math.floor((t - T_COUNTDOWN) / T_ROUND)));
  const revealed = (i: number) => t >= T_COUNTDOWN + i * T_ROUND + ROLL + 200;
  const upto = rounds.map((_, i) => i).filter(revealed);
  const sums = r.players.map((_, s) => upto.reduce((a, i) => a + rounds[i][s].value, 0));
  const over = r.status === "finished" || now >= roomEnd(r);
  const teamSum = (slot: number) => r.players.filter((x) => TEAM(r.mode, x.slot) === TEAM(r.mode, slot)).reduce((a, x) => a + sums[x.slot], 0);
  const meSlot = r.players.find((s) => s.pid === p.id);
  const won = meSlot && r.winners?.includes(meSlot.slot);
  const countdown = t < T_COUNTDOWN;
  const caseId = r.cases[cur];
  const [rm, setRm] = useState(false);

  return (
    <div className="pb-8">
      <Header title={`Баттл ${r.code}`} sub={`${MODES[r.mode].label} · раунд ${Math.min(cur + 1, n)}/${n}`} onBack={() => go("/battles")} right={<Money n={r.cost} className="text-xs text-gold" />} />
      {countdown && <div className="pop py-6 text-center"><div className="font-display text-7xl font-bold text-red">{Math.max(1, Math.ceil((T_COUNTDOWN - t) / 1000))}</div><div className="text-xs uppercase tracking-[.3em] text-white/50">Старт баттла</div></div>}
      {!countdown && !over && <div className="px-4 pb-2 text-center text-xs uppercase tracking-widest text-white/50">Открываем: <b className="text-white">{CASE_BY_ID[caseId].name}</b></div>}

      <div className="space-y-2.5 px-3">
        {r.players.map((s, i) => {
          const win = r.status === "finished" && r.winners?.includes(s.slot);
          const d = rounds[cur][i];
          return (
            <div key={i} className={cx("hud border bg-panel", win ? "border-gold shadow-[0_0_24px_-6px_#ffc83d]" : s.pid === p.id ? "border-violet/60" : "border-line")}>
              <div className="flex items-center gap-2 px-3 py-2">
                <Avatar idx={s.avatar} nick={s.nick} size={28} />
                <div className="flex-1 truncate font-display text-sm font-bold">{s.nick}{s.pid === p.id && <span className="ml-1 text-[10px] text-violet">(вы)</span>}{r.mode === "2v2" && <span className="ml-2 text-[10px] text-white/40">{i < 2 ? "A" : "B"}</span>}</div>
                {win && <span className="bg-gold px-1.5 text-[10px] font-bold text-black">ПОБЕДИТЕЛЬ</span>}
                <Money n={r.mode === "2v2" ? teamSum(i) : sums[i]} className="text-sm text-gold" />
              </div>
              {!countdown && !over && <Roller key={cur + ":" + i} compact caseId={caseId} result={d} seed={`${r.code}:${cur}:${i}`} startAt={start + T_COUNTDOWN + cur * T_ROUND} duration={ROLL} />}
              <div className="flex gap-1 overflow-x-auto px-2 py-2">
                {rounds.map((rd, k) => {
                  const sk = SKIN_BY_ID[rd[i].skinId], show = revealed(k);
                  return (
                    <div key={k} className="rar-bg flex h-14 w-16 shrink-0 flex-col items-center justify-center border border-line" style={{ ["--c" as string]: show ? rc(sk) : "#222" }}>
                      {show ? <><SkinImg skin={sk} className="h-8 w-12" /><div className="font-mono text-[9px] text-gold">{fmt(rd[i].value)}</div></> : <span className="text-white/20">?</span>}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {r.status === "finished" && (
        <div className="pop mx-4 mt-4 border border-gold/50 bg-gold/10 p-4 text-center">
          <div className={cx("font-display text-3xl font-bold uppercase", meSlot ? (won ? "text-gold" : "text-red") : "")}>{meSlot ? (won ? "Победа!" : "Поражение") : "Баттл завершён"}</div>
          <div className="mt-1 text-sm text-white/60">Общий банк: <Money n={r.prize ?? 0} className="text-gold" /></div>
          {meSlot && won && <div className="text-xs text-white/50">Все предметы уже в вашем инвентаре</div>}
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Btn tone="red" busy={rm} onClick={async () => { setRm(true); try { go("/room/" + (await rematch(r.code))); } catch (e) { toastErr(e); } finally { setRm(false); } }}>{r.rematch ? "К реваншу" : "Реванш"}</Btn>
            <Btn tone="ghost" onClick={() => go("/battles")}>В лобби</Btn>
          </div>
        </div>
      )}
      {r.status === "running" && over && <div className="pulse-s py-4 text-center text-xs text-white/50">Подсчёт результатов на сервере…</div>}
    </div>
  );
}
