import { useMemo, useState } from "react";
import { RARITY } from "../data/cases";
import { SKINS, SKIN_BY_ID, type RarityKey } from "../data/skins";
import { AVATAR_COLORS, QUESTS, addFriend, claimQuest, fmt, invValue, newPlayer, questKey, removeFriend, sellItems, setProfile, switchPlayer, useDB, useMe, wearLabel, type Item, type Player } from "../lib/engine";
import { Avatar, Btn, Header, Money, Sheet, SkinCard, SkinImg, Tabs, cx, rc, toast, toastErr } from "../lib/ui";

type Tab = "inv" | "col" | "hist" | "friends" | "quests";

export default function Profile({ go, initTab }: { go: (p: string) => void; initTab?: string }) {
  const p = useMe(), db = useDB();
  const [tab, setTab] = useState<Tab>((initTab as Tab) || "inv");
  const [edit, setEdit] = useState(false), [nick, setNick] = useState(p.nick), [av, setAv] = useState(p.avatar);
  return (
    <div className="pb-8">
      <Header title="Профиль" right={<button onClick={() => { setNick(p.nick); setAv(p.avatar); setEdit(true); }} className="hud bg-panel2 px-3 py-2 text-xs font-bold uppercase">Изменить</button>} />
      <div className="mx-4 hud border border-line bg-gradient-to-br from-[#221a46] to-panel p-4">
        <div className="flex items-center gap-3">
          <Avatar idx={p.avatar} nick={p.nick} size={60} />
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-2xl font-bold">{p.nick}</div>
            <button onClick={() => { navigator.clipboard?.writeText(p.uid); toast("ID скопирован"); }} className="font-mono text-xs text-white/50">ID {p.uid} ⧉</button>
          </div>
          <div className="text-right"><div className="text-[9px] uppercase tracking-widest text-white/40">Баланс</div><Money n={p.balance} className="text-lg text-gold" /></div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-1.5 text-center">
          {[["Инвентарь", fmt(invValue(p))], ["Кейсов", p.stats.cases], ["Баттлов", p.stats.battles], ["Победы", p.stats.wins], ["Поражения", p.stats.losses], ["Апгрейдов", p.stats.upgrades]].map(([l, v]) => (
            <div key={l} className="bg-black/40 py-2"><div className="font-mono text-sm font-bold">{v}</div><div className="text-[9px] uppercase tracking-wider text-white/40">{l}</div></div>
          ))}
        </div>
      </div>
      <div className="mt-4" />
      <Tabs value={tab} onChange={setTab} items={[["inv", "Инвентарь"], ["col", "Коллекция"], ["quests", "Задания"], ["hist", "История"], ["friends", "Друзья"]]} />
      {tab === "inv" && <Inventory go={go} p={p} />}
      {tab === "col" && <Collection p={p} />}
      {tab === "quests" && <Quests p={p} />}
      {tab === "hist" && <History p={p} />}
      {tab === "friends" && <Friends p={p} go={go} />}

      <div className="mx-4 mt-8 border-t border-line pt-4">
        <div className="mb-2 font-display text-sm font-bold uppercase">Аккаунты на устройстве</div>
        <div className="space-y-1.5">
          {Object.values(db.players).map((a) => (
            <button key={a.id} onClick={() => { switchPlayer(a.id); toast("Аккаунт: " + a.nick); }} className={cx("flex w-full items-center gap-3 bg-panel2 p-2 text-left", a.id === p.id && "ring-1 ring-violet")}>
              <Avatar idx={a.avatar} nick={a.nick} size={28} /><span className="flex-1 text-sm">{a.nick}</span><span className="font-mono text-[11px] text-white/40">{a.uid}</span>
            </button>
          ))}
        </div>
        <Btn tone="ghost" className="mt-2 w-full" onClick={() => newPlayer().then(() => toast("Создан новый игрок (+50 000)"))}>+ Новый игрок (для теста баттла в другой вкладке)</Btn>
      </div>

      <Sheet open={edit} onClose={() => setEdit(false)} title="Редактировать профиль">
        <input value={nick} onChange={(e) => setNick(e.target.value)} maxLength={16} className="w-full border border-line bg-panel2 px-3 py-3 outline-none focus:border-violet" />
        <div className="my-4 flex flex-wrap gap-2">{AVATAR_COLORS.map((_, i) => <button key={i} onClick={() => setAv(i)} className={cx("p-0.5", av === i && "ring-2 ring-white")}><Avatar idx={i} nick={nick || "??"} size={40} /></button>)}</div>
        <Btn className="w-full" onClick={async () => { try { await setProfile(nick, av); setEdit(false); } catch (e) { toastErr(e); } }}>Сохранить</Btn>
      </Sheet>
    </div>
  );
}

function Inventory({ p, go }: { p: Player; go: (x: string) => void }) {
  const [q, setQ] = useState(""), [type, setType] = useState("all"), [rar, setRar] = useState("all"), [price, setPrice] = useState("all"), [sort, setSort] = useState("new"), [sel, setSel] = useState<string[]>([]), [det, setDet] = useState<Item | null>(null);
  const types = ["all", ...new Set(SKINS.map((s) => s.type))];
  const ranges: Record<string, [number, number]> = { all: [0, 5_000_001], a: [0, 1000], b: [1000, 10000], c: [10000, 100000], d: [100000, 1_000_000], e: [1_000_000, 5_000_001] };
  const rows = useMemo(() => p.inventory.filter((i) => { const s = SKIN_BY_ID[i.skinId]; return s.name.toLowerCase().includes(q.toLowerCase()) && (type === "all" || s.type === type) && (rar === "all" || s.rarity === rar) && i.value >= ranges[price][0] && i.value < ranges[price][1]; }).sort((a, b) => sort === "pd" ? b.value - a.value : sort === "pa" ? a.value - b.value : sort === "n" ? SKIN_BY_ID[a.skinId].name.localeCompare(SKIN_BY_ID[b.skinId].name) : b.at - a.at), [p.inventory, q, type, rar, price, sort]);
  const chip = (on: boolean) => cx("shrink-0 px-3 py-1.5 text-xs", on ? "bg-white font-bold text-black" : "bg-panel2 text-white/55");
  const sell = async (ids: string[]) => { try { toast(`Продано: +${fmt(await sellItems(ids))}`); setSel([]); setDet(null); } catch (e) { toastErr(e); } };
  const selVal = p.inventory.filter((i) => sel.includes(i.iid)).reduce((a, i) => a + i.value, 0);
  return (
    <div>
      <div className="space-y-2 px-4 pb-3">
        <div className="flex items-center justify-between text-xs text-white/50"><span>{p.inventory.length} предметов</span><span>Стоимость: <Money n={invValue(p)} className="text-gold" /></span></div>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск…" className="w-full border border-line bg-panel2 px-3 py-2.5 text-sm outline-none focus:border-violet" />
        <div className="flex gap-1.5 overflow-x-auto">{types.map((t) => <button key={t} onClick={() => setType(t)} className={chip(type === t)}>{t === "all" ? "Все типы" : t}</button>)}</div>
        <div className="flex gap-1.5 overflow-x-auto">
          <button onClick={() => setRar("all")} className={chip(rar === "all")}>Любая</button>
          {(Object.keys(RARITY) as RarityKey[]).map((k) => <button key={k} onClick={() => setRar(k)} className={chip(rar === k)} style={rar === k ? undefined : { color: RARITY[k].color }}>{RARITY[k].label}</button>)}
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="ml-auto shrink-0 bg-panel2 px-2 text-xs text-white/70"><option value="new">Новые</option><option value="pd">Цена ↓</option><option value="pa">Цена ↑</option><option value="n">Название</option></select>
        </div>
        <div className="flex gap-1.5 overflow-x-auto">
          {[["all", "Любая цена"], ["a", "< 1k"], ["b", "1k–10k"], ["c", "10k–100k"], ["d", "100k–1M"], ["e", "1M–5M"]].map(([key, label]) => <button key={key} onClick={() => setPrice(key)} className={chip(price === key)}>{label}</button>)}
        </div>
        {p.inventory.length > 0 && <div className="flex gap-2"><Btn tone="gold" className="flex-1 !py-2 !text-[11px]" disabled={!sel.length} onClick={() => sell(sel)}>Продать выбранные · {fmt(selVal)}</Btn><Btn tone="ghost" className="!py-2 !text-[11px]" onClick={() => setSel(sel.length === rows.length ? [] : rows.map((r) => r.iid))}>{sel.length === rows.length ? "Снять" : "Выбрать всё"}</Btn></div>}
      </div>
      {p.inventory.length === 0 && <div className="px-4 py-10 text-center text-sm text-white/40">Инвентарь пуст.<br /><button className="mt-2 text-violet" onClick={() => go("/cases")}>Открыть первый кейс →</button></div>}
      <div className="grid grid-cols-2 gap-3 px-4">
        {rows.map((i) => <SkinCard key={i.iid} skin={SKIN_BY_ID[i.skinId]} value={i.value} wear={i.wear} selected={sel.includes(i.iid)} onClick={() => (sel.length ? setSel((s) => s.includes(i.iid) ? s.filter((x) => x !== i.iid) : [...s, i.iid]) : setDet(i))} badge={<span onClick={(e) => { e.stopPropagation(); setSel((s) => s.includes(i.iid) ? s.filter((x) => x !== i.iid) : [...s, i.iid]); }} className={cx("absolute right-1.5 top-2 flex h-5 w-5 items-center justify-center border text-[11px]", sel.includes(i.iid) ? "border-white bg-white text-black" : "border-white/30 bg-black/50")}>{sel.includes(i.iid) ? "✓" : ""}</span>} />)}
      </div>
      <Sheet open={!!det} onClose={() => setDet(null)} title={det ? SKIN_BY_ID[det.skinId].name : ""}>
        {det && (() => { const s = SKIN_BY_ID[det.skinId]; return (
          <div>
            <div className="rar-bg" style={{ ["--c" as string]: rc(s) }}><SkinImg skin={s} className="mx-auto h-40 w-full" /></div>
            <div className="mt-2 text-xs font-bold uppercase" style={{ color: rc(s) }}>{RARITY[s.rarity].label} · {s.quality} · {s.type}</div>
            <div className="mt-1 text-sm text-white/60">{wearLabel(det.wear)} · float {det.float.toFixed(4)}</div>
            <div className="text-xs text-white/40">Получено: {new Date(det.at).toLocaleString("ru-RU")} · {det.src}</div>
            <Money n={det.value} className="mt-2 text-xl text-gold" />
            <div className="mt-4 grid grid-cols-2 gap-2"><Btn tone="gold" onClick={() => sell([det.iid])}>Продать</Btn><Btn tone="violet" onClick={() => { sessionStorage.setItem("upSrc", det.iid); go("/upgrade"); }}>В апгрейд</Btn></div>
          </div>); })()}
      </Sheet>
    </div>
  );
}

function Collection({ p }: { p: Player }) {
  const own = new Set(p.inventory.map((i) => i.skinId));
  return (
    <div className="px-4">
      <div className="mb-3 flex items-center gap-3"><div className="font-mono text-sm">{own.size}/{SKINS.length}</div><div className="h-1.5 flex-1 bg-panel2"><div className="h-full bg-violet" style={{ width: (own.size / SKINS.length) * 100 + "%" }} /></div></div>
      <div className="grid grid-cols-3 gap-2">
        {SKINS.map((s) => (
          <div key={s.id} className={cx("rar-bg hud border border-line p-1.5 text-center", !own.has(s.id) && "opacity-30 grayscale")} style={{ ["--c" as string]: rc(s) }}>
            <SkinImg skin={s} className="h-12 w-full" /><div className="truncate text-[9px] font-semibold">{s.skin}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Quests({ p }: { p: Player }) {
  const groups: [string, "daily" | "season" | "once"][] = [["Ежедневные", "daily"], ["Сезонные", "season"], ["Достижения", "once"]];
  return (
    <div className="space-y-5 px-4">
      {groups.map(([title, per]) => (
        <div key={per}>
          <div className="mb-2 font-display text-sm font-bold uppercase">{title}</div>
          <div className="space-y-2">
            {QUESTS.filter((q) => q.period === per).map((q) => {
              const v = Math.min(q.prog(p), q.goal), done = v >= q.goal, got = p.claimed[q.id] === questKey(q);
              return (
                <div key={q.id} className="flex items-center gap-3 bg-panel2 p-3">
                  <div className="min-w-0 flex-1"><div className="text-sm font-semibold">{q.title}</div><div className="mt-1.5 h-1 bg-black"><div className="h-full bg-violet" style={{ width: (v / q.goal) * 100 + "%" }} /></div><div className="mt-1 font-mono text-[10px] text-white/40">{fmt(v)}/{fmt(q.goal)}</div></div>
                  {got ? <span className="text-xs text-white/40">✓ Получено</span> : <Btn tone={done ? "gold" : "ghost"} disabled={!done} className="!px-3 !py-2 !text-[11px]" onClick={async () => { try { toast(`+${fmt(await claimQuest(q.id))}`); } catch (e) { toastErr(e); } }}>{fmt(q.reward)}</Btn>}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function History({ p }: { p: Player }) {
  return (
    <div className="space-y-1.5 px-4">
      {p.tx.map((t) => (
        <div key={t.id} className="flex items-center gap-3 bg-panel2 px-3 py-2.5">
          <div className="min-w-0 flex-1"><div className="truncate text-sm">{t.text}</div><div className="text-[10px] text-white/40">{new Date(t.at).toLocaleString("ru-RU")}</div></div>
          {t.amount !== 0 && <Money n={t.amount} sign className={t.amount > 0 ? "text-[#3be8a0]" : "text-red"} />}
        </div>
      ))}
    </div>
  );
}

function Friends({ p, go }: { p: Player; go: (x: string) => void }) {
  const db = useDB(), [id, setId] = useState("");
  return (
    <div className="px-4">
      <div className="mb-3 flex gap-2">
        <input value={id} onChange={(e) => setId(e.target.value)} placeholder="ID друга, напр. #12345678" className="min-w-0 flex-1 border border-line bg-panel2 px-3 py-2.5 font-mono text-sm outline-none focus:border-violet" />
        <Btn tone="violet" onClick={async () => { try { await addFriend(id); setId(""); toast("Друг добавлен"); } catch (e) { toastErr(e); } }}>Добавить</Btn>
      </div>
      <div className="mb-3 text-xs text-white/40">Ваш ID: <span className="font-mono text-white/70">{p.uid}</span></div>
      <div className="space-y-1.5">
        {p.friends.length === 0 && <div className="py-8 text-center text-sm text-white/40">Друзей пока нет.</div>}
        {p.friends.map((f) => db.players[f]).filter(Boolean).map((f) => (
          <div key={f.id} className="flex items-center gap-3 bg-panel2 p-2.5">
            <button onClick={() => go("/player/" + f.id)}><Avatar idx={f.avatar} nick={f.nick} size={36} /></button>
            <button onClick={() => go("/player/" + f.id)} className="flex-1 text-left"><div className="text-sm font-semibold">{f.nick}</div><div className="font-mono text-[10px] text-white/40">{f.uid} · {f.stats.wins} поб.</div></button>
            <button className="text-white/30" onClick={() => removeFriend(f.id)}>×</button>
          </div>
        ))}
      </div>
    </div>
  );
}
